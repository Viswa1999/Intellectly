import React, { useState, useRef, useCallback, useEffect, useMemo } from "react";
import {
  Plus, Trash2, Play, RotateCcw, Download, Clock, BookOpen, Coffee,
  Sparkles, X, Edit2, GripVertical, Target, ListChecks, FileText, Printer, Info,
  Moon, Sun, Undo2, Redo2, Copy, Maximize2, Minimize2, BarChart3, UserX,
  ChevronDown, ChevronUp, Search, Check, AlertTriangle, Save, Upload, Zap,
  Calendar, Users, TrendingUp, Award, Bell, Settings, Eye, EyeOff, Layers, RefreshCw,
  Flame, HeartPulse, Grid, Sliders, ShieldCheck, HelpCircle
} from "lucide-react";

/* ================================================================
   CONSTANTS
   ================================================================ */

const DAY_OPTIONS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const DAY_FULL = { Mon: "Monday", Tue: "Tuesday", Wed: "Wednesday", Thu: "Thursday", Fri: "Friday", Sat: "Saturday", Sun: "Sunday" };

const SUBJECT_COLORS = [
  { bg: "rgba(139,111,214,0.12)", border: "#8B6FD6", text: "#4A3789", dot: "#8B6FD6", glow: "rgba(139,111,214,0.25)", load: 3 },
  { bg: "rgba(63,155,118,0.12)", border: "#3F9B76", text: "#215C43", dot: "#3F9B76", glow: "rgba(63,155,118,0.25)", load: 3 },
  { bg: "rgba(219,138,76,0.12)", border: "#DB8A4C", text: "#8A4E1D", dot: "#DB8A4C", glow: "rgba(219,138,76,0.25)", load: 3 },
  { bg: "rgba(214,110,133,0.12)", border: "#D66E85", text: "#8A2F42", dot: "#D66E85", glow: "rgba(214,110,133,0.25)", load: 2 },
  { bg: "rgba(76,134,196,0.12)", border: "#4C86C4", text: "#1F4D7A", dot: "#4C86C4", glow: "rgba(76,134,196,0.25)", load: 3 },
  { bg: "rgba(201,162,39,0.12)", border: "#C9A227", text: "#7A6415", dot: "#C9A227", glow: "rgba(201,162,39,0.25)", load: 2 },
  { bg: "rgba(111,118,176,0.12)", border: "#6F76B0", text: "#363C6E", dot: "#363C6E", glow: "rgba(111,118,176,0.25)", load: 2 },
  { bg: "rgba(140,129,104,0.12)", border: "#8C8168", text: "#4E4735", dot: "#8C8168", glow: "rgba(140,129,104,0.25)", load: 1 },
  { bg: "rgba(192,96,168,0.12)", border: "#C060A8", text: "#7A2E64", dot: "#C060A8", glow: "rgba(192,96,168,0.25)", load: 1 },
  { bg: "rgba(47,169,138,0.12)", border: "#2FA98A", text: "#136350", dot: "#2FA98A", glow: "rgba(47,169,138,0.25)", load: 2 },
  { bg: "rgba(220,80,80,0.12)", border: "#DC5050", text: "#7A1F1F", dot: "#DC5050", glow: "rgba(220,80,80,0.25)", load: 3 },
  { bg: "rgba(80,160,220,0.12)", border: "#50A0DC", text: "#1F5A7A", dot: "#50A0DC", glow: "rgba(80,160,220,0.25)", load: 2 },
];

const TYPE_BADGES = {
  Theory: { bg: "#EEF2FF", color: "#4338CA", icon: "📘", load: 3 },
  Lab: { bg: "#FEF3C7", color: "#B45309", icon: "🔬", load: 2 },
  Elective: { bg: "#F0FDF4", color: "#166534", icon: "✨", load: 2 },
  Activity: { bg: "#FFF1F2", color: "#BE123C", icon: "🎯", load: 1 },
};

const HEATMAP_COLORS = {
  3: { bg: "rgba(225, 29, 72, 0.18)", border: "#E11D48", text: "#9F1239", label: "High Cognitive Load" },
  2: { bg: "rgba(217, 119, 6, 0.18)", border: "#D97706", text: "#92400E", label: "Medium Load" },
  1: { bg: "rgba(16, 185, 129, 0.18)", border: "#10B981", text: "#065F46", label: "Light / Activity" },
};

const uid = () => Math.random().toString(36).slice(2, 10);
const STORAGE_KEY = "timeweave-autosave-v3";

/* ================================================================
   THEME DEFINITIONS
   ================================================================ */

const THEMES = {
  light: {
    bg: "#FAF8F3", bgAlt: "#fff", bgCard: "rgba(255,255,255,0.85)", bgPanel: "rgba(255,255,255,0.72)",
    bgHeader: "linear-gradient(135deg, #1a1d4e 0%, #2d3180 50%, #1a1d4e 100%)",
    bgOptimizer: "linear-gradient(135deg, #1e2260 0%, #2a2f78 50%, #1e2260 100%)",
    text: "#2C2A24", textSoft: "#6B6552", textMuted: "#A39D89", textInverse: "#fff",
    border: "#EDE8DB", borderSoft: "#F2EEE2", accent: "#E8A33D", accentText: "#22265E",
    cardShadow: "0 4px 24px rgba(0,0,0,0.04), 0 1px 3px rgba(0,0,0,0.06)",
    cellHover: "rgba(232,163,61,0.08)", danger: "#E53E3E", success: "#38A169",
    glass: "rgba(255,255,255,0.6)", glassBorder: "rgba(237,232,219,0.8)",
  },
  dark: {
    bg: "#0f1023", bgAlt: "#181a32", bgCard: "rgba(24,26,50,0.85)", bgPanel: "rgba(24,26,50,0.72)",
    bgHeader: "linear-gradient(135deg, #0a0c1e 0%, #151838 50%, #0a0c1e 100%)",
    bgOptimizer: "linear-gradient(135deg, #12143a 0%, #1a1d55 50%, #12143a 100%)",
    text: "#E8E6E0", textSoft: "#9B97A0", textMuted: "#6B6780", textInverse: "#0f1023",
    border: "#2a2d50", borderSoft: "#222545", accent: "#E8A33D", accentText: "#0f1023",
    cardShadow: "0 4px 24px rgba(0,0,0,0.3), 0 1px 3px rgba(0,0,0,0.2)",
    cellHover: "rgba(232,163,61,0.12)", danger: "#FC8181", success: "#68D391",
    glass: "rgba(24,26,50,0.6)", glassBorder: "rgba(42,45,80,0.8)",
  },
};

/* ================================================================
   SAMPLE DATA & PRESETS
   ================================================================ */

function sampleSubjects() {
  return [
    { id: uid(), name: "Mathematics", code: "MA101", teacher: "", periodsPerWeek: 6, color: 0, type: "Theory" },
    { id: uid(), name: "Physics", code: "PH101", teacher: "", periodsPerWeek: 5, color: 1, type: "Theory" },
    { id: uid(), name: "Chemistry", code: "CH101", teacher: "", periodsPerWeek: 5, color: 2, type: "Theory" },
    { id: uid(), name: "English", code: "EN101", teacher: "", periodsPerWeek: 5, color: 3, type: "Theory" },
    { id: uid(), name: "Biology", code: "BI101", teacher: "", periodsPerWeek: 4, color: 4, type: "Theory" },
    { id: uid(), name: "Computer Science", code: "CS101", teacher: "", periodsPerWeek: 4, color: 5, type: "Lab" },
    { id: uid(), name: "Open Elective", code: "OE101", teacher: "", periodsPerWeek: 4, color: 10, type: "Elective" },
    { id: uid(), name: "History", code: "HI101", teacher: "", periodsPerWeek: 4, color: 6, type: "Theory" },
    { id: uid(), name: "Physical Education", code: "PE101", teacher: "", periodsPerWeek: 3, color: 7, type: "Activity" },
    { id: uid(), name: "Art & Craft", code: "AR101", teacher: "", periodsPerWeek: 3, color: 8, type: "Activity" },
    { id: uid(), name: "Moral Science", code: "MS101", teacher: "", periodsPerWeek: 2, color: 9, type: "Theory" },
  ];
}

function sampleOutcomes() {
  return {
    courseOutcomes: [
      { id: uid(), code: "CO1", text: "Recall and explain core concepts introduced across the week's subjects." },
      { id: uid(), code: "CO2", text: "Apply theoretical knowledge to solve subject-specific problems independently." },
      { id: uid(), code: "CO3", text: "Analyze real-world scenarios using concepts learned in lab and theory sessions." },
    ],
    programOutcomes: [
      { id: uid(), code: "PO1", text: "Foundational knowledge — apply knowledge of core subjects to the discipline." },
      { id: uid(), code: "PO2", text: "Problem analysis — identify and analyze problems using first principles." },
      { id: uid(), code: "PO3", text: "Lifelong learning — recognize the need for continued self-directed learning." },
    ],
  };
}

function defaultSlotTemplate() {
  return [
    { id: uid(), type: "period", label: "Period 1", duration: 40 },
    { id: uid(), type: "period", label: "Period 2", duration: 40 },
    { id: uid(), type: "period", label: "Period 3", duration: 40 },
    { id: uid(), type: "break", label: "Short break", duration: 10 },
    { id: uid(), type: "period", label: "Period 4", duration: 40 },
    { id: uid(), type: "period", label: "Period 5", duration: 40 },
    { id: uid(), type: "break", label: "Lunch break", duration: 35, isLunch: true },
    { id: uid(), type: "period", label: "Period 6", duration: 40 },
    { id: uid(), type: "period", label: "Period 7", duration: 40 },
    { id: uid(), type: "break", label: "Short break", duration: 10 },
    { id: uid(), type: "period", label: "Period 8", duration: 40 },
    { id: uid(), type: "period", label: "Period 9", duration: 40 },
  ];
}

/* ================================================================
   CALENDAR (.ics) EXPORTER
   ================================================================ */

function exportICalendar(section) {
  const activeDays = section.activeDays || ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const template = section.template || defaultSlotTemplate();
  const periodSlots = template.filter((s) => s.type === "period");
  const timedSlots = computeTimes(template, section.startMinutes || 9 * 60);

  const dayOffsets = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 0 };
  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() + ((1 + 7 - baseDate.getDay()) % 7)); // Next Monday

  let icsContent = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//TimeWeave AI Timetable Builder//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `X-WR-CALNAME:${section.sectionName || "Timetable"} Schedule`,
  ];

  activeDays.forEach((day) => {
    const offset = (dayOffsets[day] - 1 + 7) % 7;
    const targetDate = new Date(baseDate);
    targetDate.setDate(baseDate.getDate() + offset);

    periodSlots.forEach((slot) => {
      const key = `${day}-${slot.id}`;
      const subjId = section.schedule[key];
      if (!subjId) return;

      const subj = section.subjects.find((s) => s.id === subjId);
      if (!subj) return;

      const timeSlot = timedSlots.find((t) => t.id === slot.id);
      if (!timeSlot) return;

      const startH = String(Math.floor(timeSlot.start / 60)).padStart(2, "0");
      const startM = String(timeSlot.start % 60).padStart(2, "0");
      const endH = String(Math.floor(timeSlot.end / 60)).padStart(2, "0");
      const endM = String(timeSlot.end % 60).padStart(2, "0");

      const yyyy = targetDate.getFullYear();
      const mm = String(targetDate.getMonth() + 1).padStart(2, "0");
      const dd = String(targetDate.getDate()).padStart(2, "0");

      const dtStart = `${yyyy}${mm}${dd}T${startH}${startM}00`;
      const dtEnd = `${yyyy}${mm}${dd}T${endH}${endM}00`;

      icsContent.push(
        "BEGIN:VEVENT",
        `UID:${uid()}@timeweave.app`,
        `SUMMARY:${subj.name} (${subj.code || "Class"})`,
        `DESCRIPTION:Teacher: ${subj.teacher || "TBA"} | Section: ${section.sectionName}`,
        `DTSTART:${dtStart}`,
        `DTEND:${dtEnd}`,
        "RRULE:FREQ=WEEKLY",
        "END:VEVENT"
      );
    });
  });

  icsContent.push("END:VCALENDAR");

  const blob = new Blob([icsContent.join("\r\n")], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${(section.sectionName || "timetable").replace(/[^a-z0-9]+/gi, "-")}-schedule.ics`;
  a.click();
  URL.revokeObjectURL(url);
  addToast("Exported to Google/Apple Calendar (.ics)!", "success");
}

/* ================================================================
   AI TIMETABLE HEALTH SCORE ENGINE
   ================================================================ */

function computeHealthScore(subjects, schedule, activeDays, periodSlots) {
  const totalSlots = activeDays.length * periodSlots.length;
  const filledSlots = Object.keys(schedule).length;

  if (totalSlots === 0 || subjects.length === 0) return { score: 100, metrics: [], advice: "Add subjects and configure periods." };

  let score = 100;
  const metrics = [];
  const advice = [];

  // 1. Fill Rate (30 pts)
  const fillPct = (filledSlots / totalSlots) * 100;
  if (fillPct < 100) {
    const penalty = Math.round((100 - fillPct) * 0.3);
    score -= penalty;
    metrics.push({ name: "Slot Coverage", status: fillPct === 100 ? "optimal" : "warning", desc: `${Math.round(fillPct)}% slots filled (${filledSlots}/${totalSlots})` });
    advice.push("Run 'Auto-generate' to populate 100% of all slots.");
  } else {
    metrics.push({ name: "Slot Coverage", status: "optimal", desc: "100% Complete — Zero gap periods!" });
  }

  // 2. Workload Balance & Back-to-Back High Load Subjects (30 pts)
  let heavyBackToBack = 0;
  activeDays.forEach((day) => {
    for (let p = 0; p < periodSlots.length - 1; p++) {
      const id1 = schedule[`${day}-${periodSlots[p].id}`];
      const id2 = schedule[`${day}-${periodSlots[p + 1].id}`];
      const s1 = subjects.find((s) => s.id === id1);
      const s2 = subjects.find((s) => s.id === id2);

      if (s1 && s2 && s1.type === "Theory" && s2.type === "Theory" && s1.id === s2.id) {
        heavyBackToBack++;
      }
    }
  });

  if (heavyBackToBack > 0) {
    score -= heavyBackToBack * 5;
    metrics.push({ name: "Subject Spacing", status: "warning", desc: `${heavyBackToBack} consecutive identical heavy subject(s)` });
    advice.push("Space out consecutive identical theory periods across days.");
  } else {
    metrics.push({ name: "Subject Spacing", status: "optimal", desc: "Balanced subject distribution throughout week." });
  }

  // 3. Morning vs. Afternoon Cognitive Energy (20 pts)
  let morningTheory = 0;
  let afternoonTheory = 0;
  activeDays.forEach((day) => {
    periodSlots.forEach((slot, idx) => {
      const sid = schedule[`${day}-${slot.id}`];
      const s = subjects.find((sub) => sub.id === sid);
      if (s && s.type === "Theory") {
        if (idx < Math.floor(periodSlots.length / 2)) morningTheory++;
        else afternoonTheory++;
      }
    });
  });

  metrics.push({ name: "Cognitive Energy Flow", status: morningTheory >= afternoonTheory ? "optimal" : "warning", desc: `${morningTheory} morning theory vs ${afternoonTheory} afternoon theory periods` });

  // 4. Elective Sync & Lab Blocks (20 pts)
  const electiveCount = subjects.filter((s) => s.type === "Elective").length;
  metrics.push({ name: "Open Electives", status: "optimal", desc: `${electiveCount} synchronized open elective track(s)` });

  score = Math.max(20, Math.min(100, Math.round(score)));

  return { score, metrics, advice };
}

function computeTimes(template, startMinutes) {
  let cursor = startMinutes;
  return template.map((slot) => {
    const start = cursor;
    const end = cursor + slot.duration;
    cursor = end;
    return { ...slot, start, end };
  });
}

function minutesToLabel(mins) {
  const h = Math.floor(mins / 60);
  const m = ((mins % 60) + 60) % 60;
  const ampm = h % 24 >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${ampm}`;
}

/* ================================================================
   TOAST SYSTEM
   ================================================================ */

let toastIdCounter = 0;
const toastListeners = new Set();
let toastList = [];

function addToast(message, type = "info", duration = 3500) {
  const t = { id: ++toastIdCounter, message, type, duration, createdAt: Date.now() };
  toastList = [...toastList, t];
  toastListeners.forEach((fn) => fn(toastList));
  setTimeout(() => {
    toastList = toastList.filter((x) => x.id !== t.id);
    toastListeners.forEach((fn) => fn(toastList));
  }, duration);
}

function useToasts() {
  const [toasts, setToasts] = useState(toastList);
  useEffect(() => {
    toastListeners.add(setToasts);
    return () => toastListeners.delete(setToasts);
  }, []);
  return toasts;
}

function ToastContainer() {
  const toasts = useToasts();
  if (toasts.length === 0) return null;
  const colors = { info: "#4C86C4", success: "#38A169", warning: "#E8A33D", error: "#E53E3E" };
  const icons = { info: "ℹ️", success: "✅", warning: "⚠️", error: "❌" };
  return (
    <div className="no-print" style={{ position: "fixed", top: 20, right: 20, zIndex: 9999, display: "flex", flexDirection: "column", gap: 8 }}>
      {toasts.map((t) => (
        <div
          key={t.id}
          className="toast-slide-in"
          style={{
            padding: "12px 18px", borderRadius: 12, background: "#fff", border: `2px solid ${colors[t.type]}`,
            boxShadow: `0 8px 32px rgba(0,0,0,0.15), 0 0 0 1px ${colors[t.type]}20`,
            display: "flex", alignItems: "center", gap: 10, fontSize: 13.5, fontWeight: 600,
            color: colors[t.type], minWidth: 280, maxWidth: 420,
            backdropFilter: "blur(12px)", animation: "toastIn 0.35s cubic-bezier(0.34,1.56,0.64,1)",
          }}
        >
          <span style={{ fontSize: 16 }}>{icons[t.type]}</span>
          <span style={{ flex: 1 }}>{t.message}</span>
        </div>
      ))}
    </div>
  );
}

/* ================================================================
   UNDO / REDO HOOK
   ================================================================ */

function useUndoRedo(initial, maxHistory = 50) {
  const [state, setState] = useState(initial);
  const undoStack = useRef([]);
  const redoStack = useRef([]);

  const set = useCallback((newState) => {
    setState((prev) => {
      undoStack.current.push(prev);
      if (undoStack.current.length > maxHistory) undoStack.current.shift();
      redoStack.current = [];
      return typeof newState === "function" ? newState(prev) : newState;
    });
  }, [maxHistory]);

  const undo = useCallback(() => {
    if (undoStack.current.length === 0) return;
    setState((prev) => {
      redoStack.current.push(prev);
      return undoStack.current.pop();
    });
    addToast("Undone", "info", 1500);
  }, []);

  const redo = useCallback(() => {
    if (redoStack.current.length === 0) return;
    setState((prev) => {
      undoStack.current.push(prev);
      return redoStack.current.pop();
    });
    addToast("Redone", "info", 1500);
  }, []);

  const canUndo = undoStack.current.length > 0;
  const canRedo = redoStack.current.length > 0;

  const replace = useCallback((newState) => {
    setState(newState);
    undoStack.current = [];
    redoStack.current = [];
  }, []);

  return { state, set, undo, redo, canUndo, canRedo, replace };
}

/* ================================================================
   GENETIC ALGORITHM — 100% FULL POPULATION ENGINE
   ================================================================ */

function runGA({ subjects, days, periodSlots, generations, populationSize }) {
  const numPeriods = periodSlots.length;
  const totalCells = days.length * numPeriods;

  let effectiveSubjects = subjects.slice();
  const currentTotal = effectiveSubjects.reduce((sum, s) => sum + s.periodsPerWeek, 0);

  if (currentTotal < totalCells) {
    const deficit = totalCells - currentTotal;
    const librarySubj = effectiveSubjects.find((s) => s.name === "Library / Self Study");
    if (librarySubj) {
      librarySubj.periodsPerWeek += deficit;
    } else {
      effectiveSubjects.push({
        id: "lib-auto-fill",
        name: "Library / Self Study",
        code: "LIB101",
        teacher: "",
        periodsPerWeek: deficit,
        color: 7,
        type: "Activity",
      });
    }
  }

  const subjectIds = effectiveSubjects.map((s) => s.id);
  const requiredCounts = {};
  effectiveSubjects.forEach((s) => (requiredCounts[s.id] = s.periodsPerWeek));

  function buildGenePool() {
    const pool = [];
    effectiveSubjects.forEach((s) => {
      for (let i = 0; i < s.periodsPerWeek; i++) pool.push(s.id);
    });
    while (pool.length < totalCells) pool.push(null);
    return pool.slice(0, totalCells);
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function randomChromosome() {
    return shuffle(buildGenePool());
  }

  function cellIndex(dayIdx, periodIdx) {
    return dayIdx * numPeriods + periodIdx;
  }

  function fitness(chromo) {
    let penalty = 0;

    const counts = {};
    chromo.forEach((g) => {
      if (g) counts[g] = (counts[g] || 0) + 1;
      else penalty += 200;
    });

    subjectIds.forEach((id) => {
      const diff = Math.abs((counts[id] || 0) - requiredCounts[id]);
      penalty += diff * 150;
    });

    for (let d = 0; d < days.length; d++) {
      const daySubjects = [];
      for (let p = 0; p < numPeriods; p++) {
        daySubjects.push(chromo[cellIndex(d, p)]);
      }

      for (let p = 0; p < daySubjects.length - 1; p++) {
        if (daySubjects[p] && daySubjects[p] === daySubjects[p + 1]) penalty += 15;
      }

      const dayCounts = {};
      daySubjects.forEach((g) => {
        if (g) dayCounts[g] = (dayCounts[g] || 0) + 1;
      });
      Object.values(dayCounts).forEach((c) => {
        if (c > 2) penalty += (c - 2) * 25;
      });
    }

    return 1 / (1 + penalty);
  }

  function tournamentSelect(pop, fitnesses, tournamentSize = 3) {
    let bestIdx = Math.floor(Math.random() * pop.length);
    for (let i = 1; i < tournamentSize; i++) {
      const idx = Math.floor(Math.random() * pop.length);
      if (fitnesses[idx] > fitnesses[bestIdx]) bestIdx = idx;
    }
    return pop[bestIdx];
  }

  function orderCrossover(p1, p2) {
    const n = p1.length;
    const start = Math.floor(Math.random() * n);
    const end = start + Math.floor(Math.random() * (n - start));
    const child = new Array(n).fill(undefined);
    const childCounts = {};

    for (let i = start; i < end; i++) {
      child[i] = p1[i];
      if (p1[i]) childCounts[p1[i]] = (childCounts[p1[i]] || 0) + 1;
    }

    let p2Idx = 0;
    for (let i = 0; i < n; i++) {
      if (child[i] !== undefined) continue;
      while (p2Idx < n) {
        const gene = p2[p2Idx];
        p2Idx++;
        if (gene) {
          const currentCount = childCounts[gene] || 0;
          const maxAllowed = requiredCounts[gene] || 0;
          if (currentCount < maxAllowed) {
            child[i] = gene;
            childCounts[gene] = currentCount + 1;
            break;
          }
        }
      }
      if (child[i] === undefined) child[i] = subjectIds[0] || null;
    }
    return repairChromosome(child);
  }

  function repairChromosome(chromo) {
    const c = chromo.slice();
    const counts = {};
    c.forEach((g) => {
      if (g) counts[g] = (counts[g] || 0) + 1;
    });

    const deficit = [];
    const excessIds = new Set();
    subjectIds.forEach((id) => {
      const have = counts[id] || 0;
      const need = requiredCounts[id];
      if (have < need) {
        for (let i = 0; i < need - have; i++) deficit.push(id);
      } else if (have > need) {
        excessIds.add(id);
      }
    });

    let dPtr = 0;
    for (let i = 0; i < c.length && dPtr < deficit.length; i++) {
      if (c[i] === null || (excessIds.has(c[i]) && counts[c[i]] > requiredCounts[c[i]])) {
        if (c[i]) counts[c[i]]--;
        c[i] = deficit[dPtr];
        counts[deficit[dPtr]] = (counts[deficit[dPtr]] || 0) + 1;
        dPtr++;
      }
    }
    return c;
  }

  function mutate(chromo, rate) {
    const c = chromo.slice();
    for (let i = 0; i < c.length; i++) {
      if (Math.random() < rate) {
        const j = Math.floor(Math.random() * c.length);
        [c[i], c[j]] = [c[j], c[i]];
      }
    }
    return c;
  }

  let population = [];
  for (let i = 0; i < populationSize; i++) population.push(randomChromosome());

  let best = null;
  let bestFit = -1;
  const history = [];

  for (let gen = 0; gen < generations; gen++) {
    const fitnesses = population.map(fitness);
    let genBestIdx = 0;
    for (let i = 1; i < fitnesses.length; i++) {
      if (fitnesses[i] > fitnesses[genBestIdx]) genBestIdx = i;
    }
    if (fitnesses[genBestIdx] > bestFit) {
      bestFit = fitnesses[genBestIdx];
      best = population[genBestIdx].slice();
    }
    const conflicts = Math.round((1 / bestFit - 1) * 10) / 10;
    history.push({ gen: gen + 1, bestFitness: bestFit, conflicts });

    const sortedIdx = fitnesses.map((f, i) => i).sort((a, b) => fitnesses[b] - fitnesses[a]);
    const eliteCount = Math.max(2, Math.floor(populationSize * 0.1));
    const newPop = [];
    for (let i = 0; i < eliteCount; i++) newPop.push(population[sortedIdx[i]]);

    while (newPop.length < populationSize) {
      const parentA = tournamentSelect(population, fitnesses);
      const parentB = tournamentSelect(population, fitnesses);
      let child = orderCrossover(parentA, parentB);
      const adaptiveRate = 0.08 * (1 - gen / generations) + 0.02;
      child = mutate(child, adaptiveRate);
      newPop.push(child);
    }
    population = newPop;
    if (bestFit === 1) break;
  }

  return { chromosome: best, fitness: bestFit, history, effectiveSubjects };
}

/* ================================================================
   DEFAULT SECTION FACTORY
   ================================================================ */

function makeDefaultSection(name) {
  return {
    id: uid(),
    sectionName: name,
    instituteInfo: {
      institute: "Greenfield Public School",
      className: name,
      academicYear: "2026 - 2027",
      termName: "Term 1",
      inCharge: "",
    },
    subjects: sampleSubjects(),
    activeDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    startMinutes: 9 * 60,
    template: defaultSlotTemplate(),
    schedule: {},
    outcomes: sampleOutcomes(),
    copoMatrix: {},
    notes: "",
  };
}

/* ================================================================
   ROOT COMPONENT
   ================================================================ */

export default function App() {
  const [darkMode, setDarkMode] = useState(() => {
    try {
      const saved = localStorage.getItem("timeweave-darkmode");
      if (saved !== null) return JSON.parse(saved);
    } catch {}
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches || false;
  });

  const theme = darkMode ? THEMES.dark : THEMES.light;

  const [sections, setSections] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        if (data.sections?.length) return data.sections;
      }
    } catch {}
    return [makeDefaultSection("Grade 10 - Section A"), makeDefaultSection("Grade 10 - Section B")];
  });

  const [activeSectionId, setActiveSectionId] = useState(sections[0]?.id);
  const [showMasterView, setShowMasterView] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ sections }));
      } catch {}
    }, 1000);
    return () => clearTimeout(timer);
  }, [sections]);

  useEffect(() => {
    localStorage.setItem("timeweave-darkmode", JSON.stringify(darkMode));
  }, [darkMode]);

  const activeSection = sections.find((s) => s.id === activeSectionId) || sections[0];

  function updateActiveSection(patch) {
    setSections((prev) =>
      prev.map((s) => (s.id === activeSectionId ? { ...s, ...(typeof patch === "function" ? patch(s) : patch) } : s))
    );
  }

  function handleElectiveSync(day, slotId, subjectId) {
    const curSubj = activeSection.subjects.find((s) => s.id === subjectId);
    const isElective = curSubj?.type === "Elective";

    setSections((prev) =>
      prev.map((sec) => {
        const nextSchedule = { ...sec.schedule };
        const key = `${day}-${slotId}`;
        if (isElective) {
          let targetElective = sec.subjects.find((s) => s.type === "Elective" || s.code === curSubj.code);
          if (!targetElective) {
            targetElective = {
              id: uid(),
              name: curSubj.name || "Open Elective",
              code: curSubj.code || "OE101",
              teacher: "",
              periodsPerWeek: 4,
              color: 10,
              type: "Elective",
            };
            sec.subjects = [...sec.subjects, targetElective];
          }
          nextSchedule[key] = targetElective.id;
        }
        return { ...sec, schedule: nextSchedule };
      })
    );
    addToast(`Synced Open Elective on ${DAY_FULL[day] || day} across all sections!`, "success");
  }

  function addSection() {
    const name = `New section ${sections.length + 1}`;
    const sec = makeDefaultSection(name);
    setSections((prev) => [...prev, sec]);
    setActiveSectionId(sec.id);
    addToast("New section added", "success");
  }

  function duplicateSection(id) {
    const source = sections.find((s) => s.id === id);
    if (!source) return;
    const newSec = {
      ...JSON.parse(JSON.stringify(source)),
      id: uid(),
      sectionName: `${source.sectionName} (copy)`,
    };
    newSec.instituteInfo.className = newSec.sectionName;
    setSections((prev) => [...prev, newSec]);
    setActiveSectionId(newSec.id);
    addToast(`Duplicated "${source.sectionName}"`, "success");
  }

  function removeSection(id) {
    if (sections.length === 1) {
      addToast("Can't remove the last section", "warning");
      return;
    }
    const name = sections.find((s) => s.id === id)?.sectionName;
    setSections((prev) => {
      const next = prev.filter((s) => s.id !== id);
      if (id === activeSectionId) setActiveSectionId(next[0].id);
      return next;
    });
    addToast(`Removed "${name}"`, "info");
  }

  function renameSection(id, name) {
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, sectionName: name, instituteInfo: { ...s.instituteInfo, className: name } } : s))
    );
  }

  function saveProjectJSON() {
    const blob = new Blob([JSON.stringify({ sections, version: 3 }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "timeweave-project.json";
    a.click();
    URL.revokeObjectURL(url);
    addToast("Project saved successfully!", "success");
  }

  function loadProjectJSON(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        if (data.sections && Array.isArray(data.sections) && data.sections.length) {
          setSections(data.sections);
          setActiveSectionId(data.sections[0].id);
          addToast(`Loaded project with ${data.sections.length} section(s)`, "success");
        } else {
          addToast("Invalid TimeWeave project file", "error");
        }
      } catch {
        addToast("Couldn't read that file", "error");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  const crossSectionClashes = useMemo(() => {
    const clashes = [];
    for (let i = 0; i < sections.length; i++) {
      for (let j = i + 1; j < sections.length; j++) {
        const a = sections[i];
        const b = sections[j];
        Object.entries(a.schedule).forEach(([keyA, subjIdA]) => {
          const [dayA, slotIdA] = keyA.split(/-(.+)/);
          const subjA = a.subjects.find((s) => s.id === subjIdA);
          if (!subjA || !subjA.teacher.trim()) return;
          Object.entries(b.schedule).forEach(([keyB, subjIdB]) => {
            const [dayB, slotIdB] = keyB.split(/-(.+)/);
            if (dayA !== dayB) return;
            const subjB = b.subjects.find((s) => s.id === subjIdB);
            if (!subjB || !subjB.teacher.trim() || subjB.teacher !== subjA.teacher) return;
            const aStart = computeTimes(a.template, a.startMinutes).find((t) => t.id === slotIdA);
            const bStart = computeTimes(b.template, b.startMinutes).find((t) => t.id === slotIdB);
            if (aStart && bStart && aStart.start < bStart.end && bStart.start < aStart.end) {
              clashes.push({
                teacher: subjA.teacher, day: dayA,
                sectionA: a.sectionName, subjectA: subjA.name,
                sectionB: b.sectionName, subjectB: subjB.name,
                time: `${minutesToLabel(aStart.start)}–${minutesToLabel(aStart.end)}`,
              });
            }
          });
        });
      }
    }
    return clashes;
  }, [sections]);

  return (
    <div style={{ minHeight: "100vh", background: theme.bg, transition: "background 0.4s ease" }}>
      <GlobalStyles theme={theme} darkMode={darkMode} />
      <ToastContainer />
      <SectionTabsBar
        sections={sections} activeId={activeSectionId} theme={theme}
        onSelect={setActiveSectionId} onAdd={addSection} onRemove={removeSection}
        onRename={renameSection} onDuplicate={duplicateSection}
        onSave={saveProjectJSON} onLoadClick={() => fileInputRef.current?.click()}
        clashCount={crossSectionClashes.length}
        darkMode={darkMode} onToggleDark={() => setDarkMode((d) => !d)}
        onOpenMaster={() => setShowMasterView(true)}
      />
      <input ref={fileInputRef} type="file" accept="application/json" onChange={loadProjectJSON} style={{ display: "none" }} />
      {crossSectionClashes.length > 0 && <ClashBanner clashes={crossSectionClashes} theme={theme} />}
      <SectionEditor
        key={activeSection.id} section={activeSection} onChange={updateActiveSection}
        onElectiveSync={handleElectiveSync} theme={theme} darkMode={darkMode}
      />
      {showMasterView && (
        <MasterOverviewModal
          sections={sections} theme={theme} darkMode={darkMode}
          onClose={() => setShowMasterView(false)}
        />
      )}
    </div>
  );
}

/* ================================================================
   GLOBAL STYLES & PRINT SPECIFICATIONS
   ================================================================ */

function GlobalStyles({ theme, darkMode }) {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
      * { box-sizing: border-box; margin: 0; }
      body { background: ${theme.bg}; transition: background 0.4s ease; }
      .disp { font-family: 'Space Grotesk', sans-serif; }
      ::-webkit-scrollbar { height: 6px; width: 6px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb { background: ${darkMode ? '#3a3d60' : '#D8D2C4'}; border-radius: 4px; }
      ::-webkit-scrollbar-thumb:hover { background: ${darkMode ? '#5a5d80' : '#b8b2a4'}; }
      .cell-btn { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
      .cell-btn:hover { transform: scale(1.02); filter: brightness(${darkMode ? '1.15' : '0.97'}); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
      .fade-in { animation: fadeIn 0.35s cubic-bezier(0.4,0,0.2,1); }
      @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes toastIn { from { opacity: 0; transform: translateX(100px); } to { opacity: 1; transform: translateX(0); } }
      @keyframes pulseGlow { 0%, 100% { box-shadow: 0 0 5px rgba(232,163,61,0.3); } 50% { box-shadow: 0 0 20px rgba(232,163,61,0.6); } }
      input[type=number]::-webkit-inner-spin-button { opacity: 1; }
      textarea, input, select, button { font-family: inherit; }
      .glass-card {
        background: ${theme.glass};
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid ${theme.glassBorder};
        border-radius: 16px;
        box-shadow: ${theme.cardShadow};
        transition: all 0.3s ease;
      }
      .btn-primary {
        display: flex; align-items: center; gap: 7px;
        background: linear-gradient(135deg, #E8A33D 0%, #F0B85A 100%);
        color: #22265E; border: none; border-radius: 10px;
        padding: 11px 20px; font-size: 13.5px; font-weight: 700;
        cursor: pointer; transition: all 0.2s ease;
        box-shadow: 0 4px 12px rgba(232,163,61,0.3);
      }
      .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(232,163,61,0.4); }
      .btn-ghost-dark {
        display: flex; align-items: center; gap: 6px;
        background: rgba(255,255,255,0.06); color: #fff;
        border: 1px solid rgba(255,255,255,0.15); border-radius: 10px;
        padding: 9px 14px; font-size: 13px; font-weight: 600;
        cursor: pointer; transition: all 0.2s ease;
      }
      .btn-ghost-dark:hover { background: rgba(255,255,255,0.12); border-color: rgba(255,255,255,0.25); }
      .progress-bar {
        height: 5px; border-radius: 3px; overflow: hidden;
        background: ${darkMode ? '#2a2d50' : '#EDE8DB'};
      }
      .progress-fill {
        height: 100%; border-radius: 3px;
        background: linear-gradient(90deg, #E8A33D, #F0B85A);
        transition: width 0.3s ease;
      }
      @media print {
        .no-print { display: none !important; }
        body { background: #fff !important; color: #000 !important; }
        .glass-card { background: #fff !important; backdrop-filter: none !important; border: 1px solid #ccc !important; box-shadow: none !important; }
        .print-page-1 { page-break-after: always !important; break-after: page !important; }
        .print-page-2 { page-break-before: always !important; break-before: page !important; margin-top: 20px; }
      }
    `}</style>
  );
}

/* ================================================================
   SECTION TABS BAR
   ================================================================ */

function SectionTabsBar({ sections, activeId, onSelect, onAdd, onRemove, onRename, onDuplicate, onSave, onLoadClick, clashCount, darkMode, onToggleDark, onOpenMaster, theme }) {
  const [editingId, setEditingId] = useState(null);
  return (
    <div className="no-print" style={{
      background: darkMode
        ? "linear-gradient(135deg, #080a18 0%, #10122a 100%)"
        : "linear-gradient(135deg, #12153e 0%, #1e2260 100%)",
      padding: "10px 28px", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap",
      borderBottom: `1px solid ${darkMode ? '#1a1d40' : '#2a2d60'}`,
    }}>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", flex: 1, alignItems: "center" }}>
        {sections.map((s) => (
          <div
            key={s.id}
            style={{
              display: "flex", alignItems: "center", gap: 6, padding: "7px 12px", borderRadius: 9,
              background: s.id === activeId ? "linear-gradient(135deg, #E8A33D, #F0B85A)" : "rgba(255,255,255,0.05)",
              border: s.id === activeId ? "none" : "1px solid rgba(255,255,255,0.1)",
              cursor: "pointer", transition: "all 0.2s ease",
            }}
            onClick={() => onSelect(s.id)}
          >
            {editingId === s.id ? (
              <input
                autoFocus defaultValue={s.sectionName}
                onBlur={(e) => { onRename(s.id, e.target.value || s.sectionName); setEditingId(null); }}
                onKeyDown={(e) => e.key === "Enter" && e.target.blur()}
                onClick={(e) => e.stopPropagation()}
                style={{ fontSize: 12.5, fontWeight: 600, border: "none", outline: "none", width: 120, background: "transparent", color: s.id === activeId ? "#22265E" : "#fff" }}
              />
            ) : (
              <span
                onDoubleClick={(e) => { e.stopPropagation(); setEditingId(s.id); }}
                style={{ fontSize: 12.5, fontWeight: 600, color: s.id === activeId ? "#22265E" : "#B7BBE0" }}
              >
                {s.sectionName}
              </span>
            )}
            <div style={{ display: "flex", gap: 2 }}>
              <Copy
                size={11} color={s.id === activeId ? "#22265E" : "#7A7FC0"}
                style={{ cursor: "pointer", opacity: 0.7 }}
                onClick={(e) => { e.stopPropagation(); onDuplicate(s.id); }}
              />
              {sections.length > 1 && (
                <X
                  size={12} color={s.id === activeId ? "#22265E" : "#7A7FC0"}
                  style={{ cursor: "pointer", opacity: 0.7 }}
                  onClick={(e) => { e.stopPropagation(); onRemove(s.id); }}
                />
              )}
            </div>
          </div>
        ))}
        <button onClick={onAdd} style={{
          display: "flex", alignItems: "center", gap: 4, background: "transparent",
          border: "1px dashed rgba(255,255,255,0.2)", borderRadius: 9,
          padding: "7px 12px", color: "#B7BBE0", fontSize: 12, fontWeight: 600, cursor: "pointer",
        }}>
          <Plus size={12} /> Add section
        </button>
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <button onClick={onOpenMaster} className="btn-ghost-dark" style={{ background: "rgba(232,163,61,0.15)", borderColor: "#E8A33D", color: "#E8A33D" }}>
          <Grid size={14} /> Master Overview
        </button>
        {clashCount > 0 && (
          <span style={{ fontSize: 11.5, color: "#F0A0A0", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>
            <AlertTriangle size={13} /> {clashCount} clash{clashCount > 1 ? "es" : ""}
          </span>
        )}
        <button onClick={onToggleDark} style={{
          background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 9,
          padding: "7px 10px", cursor: "pointer", display: "flex", alignItems: "center", color: "#E8A33D",
          transition: "all 0.2s ease",
        }}>
          {darkMode ? <Sun size={15} /> : <Moon size={15} />}
        </button>
        <button onClick={onLoadClick} className="btn-ghost-dark"><Upload size={14} /> Load</button>
        <button onClick={onSave} className="btn-ghost-dark"><Save size={14} /> Save</button>
      </div>
    </div>
  );
}

/* ================================================================
   CLASH BANNER
   ================================================================ */

function ClashBanner({ clashes, theme }) {
  return (
    <div className="no-print" style={{
      background: "linear-gradient(90deg, #FDE9EC, #FEEEF0)", borderBottom: `1px solid #F0C4CC`,
      padding: "10px 28px",
    }}>
      <div style={{ maxWidth: 1480, margin: "0 auto", fontSize: 12.5, color: "#8A2F42", display: "flex", alignItems: "center", gap: 8 }}>
        <AlertTriangle size={15} />
        <span>
          <strong>Teacher clash: </strong>
          {clashes.slice(0, 3).map((c, i) => (
            <span key={i}>
              {c.teacher} → {c.subjectA} ({c.sectionA}) & {c.subjectB} ({c.sectionB}) on {DAY_FULL[c.day]} at {c.time}
              {i < Math.min(clashes.length, 3) - 1 ? " · " : ""}
            </span>
          ))}
          {clashes.length > 3 ? ` +${clashes.length - 3} more` : ""}
        </span>
      </div>
    </div>
  );
}

/* ================================================================
   SECTION EDITOR
   ================================================================ */

function SectionEditor({ section, onChange, onElectiveSync, theme, darkMode }) {
  const instituteInfo = section.instituteInfo;
  const setInstituteInfo = (fnOrVal) =>
    onChange((s) => ({ instituteInfo: typeof fnOrVal === "function" ? fnOrVal(s.instituteInfo) : fnOrVal }));

  const subjects = section.subjects;
  const setSubjects = (fnOrVal) => onChange((s) => ({ subjects: typeof fnOrVal === "function" ? fnOrVal(s.subjects) : fnOrVal }));

  const activeDays = section.activeDays;
  const setActiveDays = (fnOrVal) => onChange((s) => ({ activeDays: typeof fnOrVal === "function" ? fnOrVal(s.activeDays) : fnOrVal }));

  const startMinutes = section.startMinutes;
  const setStartMinutes = (val) => onChange({ startMinutes: val });

  const template = section.template;
  const setTemplate = (fnOrVal) => onChange((s) => ({ template: typeof fnOrVal === "function" ? fnOrVal(s.template) : fnOrVal }));

  const scheduleUR = useUndoRedo(section.schedule);
  const schedule = scheduleUR.state;
  const setSchedule = scheduleUR.set;

  useEffect(() => {
    onChange({ schedule: scheduleUR.state });
  }, [scheduleUR.state]);

  const outcomes = section.outcomes || sampleOutcomes();
  const setOutcomes = (fnOrVal) => onChange((s) => ({ outcomes: typeof fnOrVal === "function" ? fnOrVal(s.outcomes || sampleOutcomes()) : fnOrVal }));

  const copoMatrix = section.copoMatrix || {};
  const setCopoMatrix = (fnOrVal) => onChange((s) => ({ copoMatrix: typeof fnOrVal === "function" ? fnOrVal(s.copoMatrix || {}) : fnOrVal }));

  const notes = section.notes;
  const setNotes = (val) => onChange({ notes: val });

  const [gaState, setGaState] = useState({ running: false, gen: 0, totalGens: 0, fitness: 0, history: [] });
  const [editingCell, setEditingCell] = useState(null);
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [newSubject, setNewSubject] = useState({ name: "", code: "", teacher: "", periodsPerWeek: 4, type: "Theory" });
  const cancelRef = useRef(false);
  const [showStats, setShowStats] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const [collapsedPanels, setCollapsedPanels] = useState({});
  const [substituteMode, setSubstituteMode] = useState(false);
  const [absentTeacher, setAbsentTeacher] = useState("");
  const [heatmapMode, setHeatmapMode] = useState(false);

  const periodSlots = template.filter((s) => s.type === "period");
  const timedTemplate = computeTimes(template, startMinutes);

  const totalRequired = subjects.reduce((sum, s) => sum + s.periodsPerWeek, 0);
  const totalCapacity = activeDays.length * periodSlots.length;

  const health = useMemo(() => computeHealthScore(subjects, schedule, activeDays, periodSlots), [subjects, schedule, activeDays, periodSlots]);

  useEffect(() => {
    const handler = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) { e.preventDefault(); scheduleUR.undo(); }
      if ((e.ctrlKey || e.metaKey) && (e.key === "y" || (e.key === "z" && e.shiftKey))) { e.preventDefault(); scheduleUR.redo(); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [scheduleUR.undo, scheduleUR.redo]);

  function addSubject() {
    if (!newSubject.name.trim()) { addToast("Subject name is required", "warning"); return; }
    const colorIdx = subjects.length % SUBJECT_COLORS.length;
    setSubjects((prev) => [
      ...prev,
      { id: uid(), name: newSubject.name.trim(), code: newSubject.code.trim(), teacher: newSubject.teacher.trim(), periodsPerWeek: newSubject.periodsPerWeek, type: newSubject.type, color: colorIdx },
    ]);
    setNewSubject({ name: "", code: "", teacher: "", periodsPerWeek: 4, type: "Theory" });
    setShowAddSubject(false);
    addToast(`Added "${newSubject.name.trim()}"`, "success");
  }

  function removeSubject(id) {
    const name = subjects.find((s) => s.id === id)?.name;
    setSubjects((prev) => prev.filter((s) => s.id !== id));
    setSchedule((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((k) => { if (next[k] === id) delete next[k]; });
      return next;
    });
    addToast(`Removed "${name}"`, "info");
  }

  function updateSubject(id, patch) {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function updateSlot(id, patch) {
    setTemplate((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function removeSlot(id) {
    setTemplate((prev) => prev.filter((s) => s.id !== id));
  }

  function addSlot(type, afterId) {
    const newItem = type === "period"
      ? { id: uid(), type: "period", label: `Period ${periodSlots.length + 1}`, duration: 40 }
      : { id: uid(), type: "break", label: "Break", duration: 10 };
    setTemplate((prev) => {
      if (!afterId) return [...prev, newItem];
      const idx = prev.findIndex((s) => s.id === afterId);
      const next = prev.slice();
      next.splice(idx + 1, 0, newItem);
      return next;
    });
  }

  function cellKey(day, slotId) {
    return `${day}-${slotId}`;
  }

  function setCellSubject(day, slotId, subjectId) {
    setSchedule((prev) => {
      const next = { ...prev };
      if (subjectId) next[cellKey(day, slotId)] = subjectId;
      else delete next[cellKey(day, slotId)];
      return next;
    });

    const subj = subjects.find((s) => s.id === subjectId);
    if (subj?.type === "Elective" && onElectiveSync) {
      onElectiveSync(day, slotId, subjectId);
    }

    setEditingCell(null);
  }

  function clearAll() {
    scheduleUR.replace({});
    setGaState({ running: false, gen: 0, totalGens: 0, fitness: 0, history: [] });
    addToast("Timetable cleared", "info");
  }

  const runOptimizer = useCallback(() => {
    if (subjects.length === 0) { addToast("Add subjects first!", "warning"); return; }
    cancelRef.current = false;
    const totalGens = 150;
    setGaState({ running: true, gen: 0, totalGens, fitness: 0, history: [] });

    setTimeout(() => {
      const result = runGA({
        subjects, days: activeDays, periodSlots,
        generations: totalGens, populationSize: 100,
      });

      if (cancelRef.current) return;

      if (result.effectiveSubjects.length > subjects.length) {
        setSubjects(result.effectiveSubjects);
      }

      let i = 0;
      const animate = () => {
        if (cancelRef.current) return;
        if (i >= result.history.length) {
          finishGA();
          return;
        }
        const point = result.history[i];
        setGaState((prev) => ({
          ...prev, gen: point.gen, fitness: point.bestFitness,
          history: [...prev.history, point],
        }));
        i += 3;
        requestAnimationFrame(animate);
      };

      function finishGA() {
        const newSchedule = {};
        let filledCount = 0;
        activeDays.forEach((day, dIdx) => {
          periodSlots.forEach((slot, pIdx) => {
            const gene = result.chromosome[dIdx * periodSlots.length + pIdx];
            if (gene) {
              newSchedule[cellKey(day, slot.id)] = gene;
              filledCount++;
            }
          });
        });
        scheduleUR.replace(newSchedule);
        onChange({ schedule: newSchedule });
        setGaState((prev) => ({ ...prev, running: false, gen: totalGens, fitness: result.fitness }));
        addToast(`Timetable generated! 100% Filled (${filledCount}/${totalCapacity} periods)`, "success");
      }

      animate();
    }, 50);
  }, [subjects, activeDays, periodSlots, totalCapacity]);

  function stopOptimizer() {
    cancelRef.current = true;
    setGaState((prev) => ({ ...prev, running: false }));
    addToast("Optimizer stopped", "info");
  }

  function exportCSV() {
    const rows = [
      [instituteInfo.institute],
      [`${instituteInfo.className} | ${instituteInfo.termName} | ${instituteInfo.academicYear}`],
      [],
      ["Time", ...activeDays.map((d) => DAY_FULL[d])],
    ];
    timedTemplate.forEach((slot) => {
      const timeLabel = `${minutesToLabel(slot.start)} - ${minutesToLabel(slot.end)}`;
      if (slot.type === "break") {
        rows.push([`${timeLabel} (${slot.label})`, ...activeDays.map(() => slot.label)]);
      } else {
        const row = [`${timeLabel} (${slot.label})`];
        activeDays.forEach((day) => {
          const subjId = schedule[cellKey(day, slot.id)];
          const subj = subjects.find((s) => s.id === subjId);
          row.push(subj ? `${subj.name} ${subj.teacher ? `(${subj.teacher})` : ""}` : "");
        });
        rows.push(row);
      }
    });
    rows.push([]);
    rows.push(["Course Outcomes"]);
    (outcomes.courseOutcomes || []).forEach((c) => rows.push([c.code, c.text]));
    rows.push([]);
    rows.push(["Program Outcomes"]);
    (outcomes.programOutcomes || []).forEach((p) => rows.push([p.code, p.text]));

    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(section.sectionName || "timetable").replace(/[^a-z0-9]+/gi, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    addToast("CSV exported!", "success");
  }

  function addOutcome(kind) {
    const key = kind === "CO" ? "courseOutcomes" : "programOutcomes";
    const prefix = kind === "CO" ? "CO" : "PO";
    setOutcomes((prev) => ({
      ...prev,
      [key]: [...prev[key], { id: uid(), code: `${prefix}${prev[key].length + 1}`, text: "" }],
    }));
  }

  function updateOutcome(kind, id, patch) {
    const key = kind === "CO" ? "courseOutcomes" : "programOutcomes";
    setOutcomes((prev) => ({
      ...prev,
      [key]: prev[key].map((o) => (o.id === id ? { ...o, ...patch } : o)),
    }));
  }

  function removeOutcome(kind, id) {
    const key = kind === "CO" ? "courseOutcomes" : "programOutcomes";
    setOutcomes((prev) => ({ ...prev, [key]: prev[key].filter((o) => o.id !== id) }));
  }

  const placedCounts = {};
  Object.values(schedule).forEach((sid) => {
    placedCounts[sid] = (placedCounts[sid] || 0) + 1;
  });

  const filled = Object.keys(schedule).length;
  const fillPct = totalCapacity > 0 ? Math.min(100, Math.round((filled / totalCapacity) * 100)) : 0;

  const teacherLoad = {};
  Object.entries(schedule).forEach(([, subjId]) => {
    const subj = subjects.find((s) => s.id === subjId);
    if (!subj || !subj.teacher.trim()) return;
    teacherLoad[subj.teacher] = (teacherLoad[subj.teacher] || 0) + 1;
  });

  const dayHours = {};
  activeDays.forEach((day) => {
    let mins = 0;
    periodSlots.forEach((slot) => {
      if (schedule[cellKey(day, slot.id)]) {
        const timedSlot = timedTemplate.find((t) => t.id === slot.id);
        mins += timedSlot ? timedSlot.duration : 40;
      }
    });
    dayHours[day] = mins;
  });

  const affectedCells = useMemo(() => {
    if (!substituteMode || !absentTeacher) return [];
    const cells = [];
    activeDays.forEach((day) => {
      periodSlots.forEach((slot) => {
        const subjId = schedule[cellKey(day, slot.id)];
        const subj = subjects.find((s) => s.id === subjId);
        if (subj && subj.teacher && subj.teacher === absentTeacher) {
          cells.push({ day, slotId: slot.id, subject: subj });
        }
      });
    });
    return cells;
  }, [substituteMode, absentTeacher, schedule, subjects, activeDays, periodSlots]);

  function togglePanel(name) {
    setCollapsedPanels((p) => ({ ...p, [name]: !p[name] }));
  }

  const inputSt = { padding: "8px 10px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: 13, background: theme.bgAlt, color: theme.text, transition: "border-color 0.2s" };
  const selectSt = { ...inputSt, cursor: "pointer" };

  return (
    <div style={{ minHeight: "100vh", fontFamily: "'Inter', sans-serif", color: theme.text, transition: "color 0.4s" }}>
      {/* Header */}
      <header className="no-print" style={{
        background: theme.bgHeader, padding: "20px 28px",
        display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 12,
            background: "linear-gradient(135deg, #E8A33D, #F0B85A)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 4px 16px rgba(232,163,61,0.4)",
          }}>
            <Clock size={22} color="#22265E" strokeWidth={2.5} />
          </div>
          <div>
            <div className="disp" style={{ fontSize: 22, fontWeight: 700, color: "#fff", lineHeight: 1.1, letterSpacing: -0.5 }}>
              TimeWeave Pro
            </div>
            <div style={{ fontSize: 12.5, color: "rgba(183,187,224,0.8)", marginTop: 2 }}>
              AI Timetable Builder · Health Score & Heatmap Engine
            </div>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 4, marginRight: 8, alignItems: "center" }}>
            <button onClick={scheduleUR.undo} disabled={!scheduleUR.canUndo} className="btn-ghost-dark" style={{ opacity: scheduleUR.canUndo ? 1 : 0.3, padding: "8px 10px" }} title="Undo (Ctrl+Z)">
              <Undo2 size={15} />
            </button>
            <button onClick={scheduleUR.redo} disabled={!scheduleUR.canRedo} className="btn-ghost-dark" style={{ opacity: scheduleUR.canRedo ? 1 : 0.3, padding: "8px 10px" }} title="Redo (Ctrl+Y)">
              <Redo2 size={15} />
            </button>
          </div>

          <button onClick={() => setHeatmapMode(!heatmapMode)} className="btn-ghost-dark" style={{ background: heatmapMode ? "rgba(225,29,72,0.2)" : undefined, borderColor: heatmapMode ? "#E11D48" : undefined }}>
            <Flame size={15} color={heatmapMode ? "#E11D48" : "#fff"} /> {heatmapMode ? "Standard View" : "Heatmap"}
          </button>

          <button onClick={() => exportICalendar(section)} className="btn-ghost-dark">
            <Calendar size={15} /> Google/iCal
          </button>

          <button onClick={() => setShowStats(!showStats)} className="btn-ghost-dark">
            <BarChart3 size={15} /> Stats
          </button>
          <button onClick={() => setShowFullscreen(true)} className="btn-ghost-dark">
            <Maximize2 size={15} /> Fullscreen
          </button>
          <button onClick={() => window.print()} className="btn-ghost-dark">
            <Printer size={15} /> Print (2-Page)
          </button>
          <button onClick={exportCSV} className="btn-ghost-dark">
            <Download size={15} /> CSV
          </button>
        </div>
      </header>

      {/* AI Timetable Health Score Bar */}
      <div className="no-print" style={{ background: theme.bgAlt, borderBottom: `1px solid ${theme.border}`, padding: "12px 28px" }}>
        <div style={{ maxWidth: 1480, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: health.score >= 90 ? "linear-gradient(135deg, #38A169, #68D391)" : "linear-gradient(135deg, #E8A33D, #F0B85A)",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 15,
            }}>
              {health.score}
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: theme.text, display: "flex", alignItems: "center", gap: 6 }}>
                <HeartPulse size={15} color={theme.accent} /> AI Schedule Quality Score
              </div>
              <div style={{ fontSize: 11.5, color: theme.textMuted }}>
                {health.metrics.map((m) => `${m.name}: ${m.desc}`).join(" · ")}
              </div>
            </div>
          </div>
          {health.advice.length > 0 && (
            <div style={{ fontSize: 11.5, color: theme.accent, fontWeight: 600, display: "flex", alignItems: "center", gap: 6, background: `${theme.accent}15`, padding: "6px 12px", borderRadius: 8 }}>
              <Sparkles size={13} /> {health.advice[0]}
            </div>
          )}
        </div>
      </div>

      {/* Main Container */}
      <div>
        {/* PAGE 1 FOR PRINTING */}
        <div className="print-page-1">
          <div style={{ background: theme.bgAlt, borderBottom: `1px solid ${theme.border}`, padding: "16px 28px", transition: "background 0.4s" }}>
            <div style={{ maxWidth: 1480, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
              <EditableField label="Institute / school name" value={instituteInfo.institute} onChange={(v) => setInstituteInfo((p) => ({ ...p, institute: v }))} big theme={theme} />
              <EditableField label="Class / section" value={instituteInfo.className} onChange={(v) => setInstituteInfo((p) => ({ ...p, className: v }))} theme={theme} />
              <EditableField label="Academic year" value={instituteInfo.academicYear} onChange={(v) => setInstituteInfo((p) => ({ ...p, academicYear: v }))} theme={theme} />
              <EditableField label="Term / semester" value={instituteInfo.termName} onChange={(v) => setInstituteInfo((p) => ({ ...p, termName: v }))} theme={theme} />
              <EditableField label="Class teacher" value={instituteInfo.inCharge} onChange={(v) => setInstituteInfo((p) => ({ ...p, inCharge: v }))} theme={theme} />
            </div>
          </div>

          {showStats && (
            <div className="fade-in no-print" style={{ padding: "16px 28px", maxWidth: 1480, margin: "0 auto" }}>
              <StatsDashboard
                subjects={subjects} schedule={schedule} activeDays={activeDays}
                periodSlots={periodSlots} cellKey={cellKey} dayHours={dayHours}
                placedCounts={placedCounts} teacherLoad={teacherLoad}
                theme={theme} darkMode={darkMode}
              />
            </div>
          )}

          <div style={{ display: "flex", maxWidth: 1480, margin: "0 auto", gap: 20, padding: "24px 28px", alignItems: "flex-start" }}>
            {/* LEFT PANEL */}
            <div className="no-print" style={{ width: 340, flexShrink: 0, display: "flex", flexDirection: "column", gap: 14 }}>

              {/* Days Panel */}
              <Panel title="Days & Timing" icon={<Calendar size={16} />} theme={theme} collapsed={collapsedPanels.days} onToggle={() => togglePanel("days")}>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {DAY_OPTIONS.map((d) => {
                    const active = activeDays.includes(d);
                    return (
                      <button
                        key={d}
                        onClick={() => {
                          setActiveDays((prev) => {
                            if (prev.includes(d)) return prev.filter((x) => x !== d);
                            return DAY_OPTIONS.filter((x) => prev.includes(x) || x === d);
                          });
                        }}
                        style={{
                          padding: "8px 14px", borderRadius: 9,
                          border: active ? "none" : `1px solid ${theme.border}`,
                          background: active ? "linear-gradient(135deg, #22265E, #2d3180)" : theme.bgAlt,
                          color: active ? "#fff" : theme.textMuted,
                          fontSize: 12.5, fontWeight: 600, cursor: "pointer", transition: "all 0.2s ease",
                        }}
                      >
                        {d}
                      </button>
                    );
                  })}
                </div>
                <div style={{ marginTop: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 12.5, color: theme.textSoft }}>Start time</span>
                  <select value={startMinutes} onChange={(e) => setStartMinutes(parseInt(e.target.value))} style={selectSt}>
                    {Array.from({ length: 13 }, (_, i) => 6 * 60 + i * 30).map((m) => (
                      <option key={m} value={m}>{minutesToLabel(m)}</option>
                    ))}
                  </select>
                </div>
              </Panel>

              {/* Periods & Breaks Panel */}
              <Panel title={`Periods & Breaks (${periodSlots.length})`} icon={<Coffee size={16} />} theme={theme} collapsed={collapsedPanels.periods} onToggle={() => togglePanel("periods")}>
                <div style={{ fontSize: 11.5, color: theme.textMuted, marginBottom: 10 }}>
                  Configure each period's name and duration. Insert breaks anywhere.
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {timedTemplate.map((slot) => (
                    <div key={slot.id}>
                      <SlotRow slot={slot} onUpdate={(patch) => updateSlot(slot.id, patch)} onRemove={() => removeSlot(slot.id)} theme={theme} />
                      <div style={{ display: "flex", gap: 4, marginTop: 3, marginBottom: 1, paddingLeft: 4 }}>
                        <MiniAddBtn onClick={() => addSlot("period", slot.id)} theme={theme}><Plus size={10} /> Period</MiniAddBtn>
                        <MiniAddBtn onClick={() => addSlot("break", slot.id)} theme={theme}><Plus size={10} /> Break</MiniAddBtn>
                      </div>
                    </div>
                  ))}
                </div>
                {template.length === 0 && (
                  <MiniAddBtn onClick={() => addSlot("period", null)} theme={theme} full><Plus size={13} /> Add first period</MiniAddBtn>
                )}
                <div style={{ marginTop: 10, fontSize: 11.5, color: theme.textMuted, display: "flex", justifyContent: "space-between" }}>
                  <span>{periodSlots.length} periods · {template.filter((s) => s.type === "break").length} breaks</span>
                  <span>Ends: {minutesToLabel(timedTemplate.length ? timedTemplate[timedTemplate.length - 1].end : startMinutes)}</span>
                </div>
              </Panel>

              {/* Subjects Panel */}
              <Panel title={`Subjects (${subjects.length})`} icon={<BookOpen size={16} />} theme={theme} collapsed={collapsedPanels.subjects} onToggle={() => togglePanel("subjects")}>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {subjects.map((s) => {
                    const c = SUBJECT_COLORS[s.color % SUBJECT_COLORS.length];
                    const placed = placedCounts[s.id] || 0;
                    const complete = placed >= s.periodsPerWeek;
                    const tb = TYPE_BADGES[s.type] || TYPE_BADGES.Theory;
                    return (
                      <div key={s.id} className="glass-card" style={{
                        display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderRadius: 10,
                        background: theme.bgCard, border: `1px solid ${theme.border}`,
                      }}>
                        <span style={{ width: 10, height: 10, borderRadius: "50%", background: c.dot, flexShrink: 0, boxShadow: `0 0 6px ${c.glow}` }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                            <input
                              value={s.name}
                              onChange={(e) => updateSubject(s.id, { name: e.target.value })}
                              style={{ fontSize: 13, fontWeight: 600, border: "none", background: "transparent", width: "100%", padding: 0, color: theme.text }}
                            />
                            <span style={{ fontSize: 9.5, padding: "2px 6px", borderRadius: 5, background: tb.bg, color: tb.color, fontWeight: 700, flexShrink: 0 }}>
                              {tb.icon} {s.type}
                            </span>
                          </div>
                          <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                            <input
                              value={s.teacher}
                              onChange={(e) => updateSubject(s.id, { teacher: e.target.value })}
                              placeholder="Type teacher name..."
                              style={{ fontSize: 11.5, color: theme.textMuted, border: "none", background: "transparent", width: "60%", padding: 0 }}
                            />
                            <input
                              value={s.code}
                              onChange={(e) => updateSubject(s.id, { code: e.target.value })}
                              placeholder="Code"
                              style={{ fontSize: 11.5, color: theme.textMuted, border: "none", background: "transparent", width: "40%", padding: 0 }}
                            />
                          </div>
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                          <input
                            type="number" min={1} max={30}
                            value={s.periodsPerWeek}
                            onChange={(e) => updateSubject(s.id, { periodsPerWeek: Math.max(1, parseInt(e.target.value) || 1) })}
                            style={{ width: 38, fontSize: 12.5, textAlign: "center", border: `1px solid ${theme.border}`, borderRadius: 7, padding: "4px 2px", background: theme.bgAlt, color: theme.text }}
                          />
                          <span style={{ fontSize: 10.5, color: complete ? theme.success : theme.textMuted, fontWeight: 700, minWidth: 30 }}>
                            {placed}/{s.periodsPerWeek}
                          </span>
                        </div>
                        <button onClick={() => removeSubject(s.id)} style={{ background: "none", border: "none", cursor: "pointer", color: theme.danger, padding: 2, opacity: 0.6 }}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    );
                  })}
                </div>

                {!showAddSubject ? (
                  <button onClick={() => setShowAddSubject(true)} style={{
                    marginTop: 10, width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    padding: "10px", borderRadius: 10, border: `1.5px dashed ${theme.border}`, background: "transparent",
                    color: theme.textSoft, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: "all 0.2s",
                  }}>
                    <Plus size={15} /> Add subject
                  </button>
                ) : (
                  <div className="fade-in" style={{ marginTop: 10, padding: 12, borderRadius: 10, background: darkMode ? theme.bgAlt : "#F4F0E5", display: "flex", flexDirection: "column", gap: 8 }}>
                    <input autoFocus placeholder="Subject name" value={newSubject.name} onChange={(e) => setNewSubject((p) => ({ ...p, name: e.target.value }))} style={inputSt} />
                    <div style={{ display: "flex", gap: 6 }}>
                      <input placeholder="Code (e.g. CS101)" value={newSubject.code} onChange={(e) => setNewSubject((p) => ({ ...p, code: e.target.value }))} style={{ ...inputSt, flex: 1 }} />
                      <select value={newSubject.type} onChange={(e) => setNewSubject((p) => ({ ...p, type: e.target.value }))} style={{ ...selectSt, flex: 1 }}>
                        <option>Theory</option><option>Lab</option><option>Elective</option><option>Activity</option>
                      </select>
                    </div>
                    <input placeholder="Teacher name" value={newSubject.teacher} onChange={(e) => setNewSubject((p) => ({ ...p, teacher: e.target.value }))} style={inputSt} />
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <label style={{ fontSize: 12, color: theme.textSoft }}>Periods/week</label>
                      <input type="number" min={1} max={30} value={newSubject.periodsPerWeek} onChange={(e) => setNewSubject((p) => ({ ...p, periodsPerWeek: Math.max(1, parseInt(e.target.value) || 1) }))} style={{ width: 50, ...inputSt, textAlign: "center" }} />
                    </div>
                    <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                      <button onClick={addSubject} className="btn-primary" style={{ flex: 1, justifyContent: "center", padding: "9px" }}>
                        <Check size={15} /> Add
                      </button>
                      <button onClick={() => setShowAddSubject(false)} style={{ padding: "9px 14px", borderRadius: 8, border: `1px solid ${theme.border}`, background: theme.bgAlt, fontSize: 12.5, cursor: "pointer", color: theme.text }}>
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                <div style={{ marginTop: 10, fontSize: 11.5, color: theme.textMuted, display: "flex", justifyContent: "space-between" }}>
                  <span>Required: {totalRequired} p/wk</span>
                  <span style={{ color: totalRequired > totalCapacity ? theme.danger : theme.textMuted, fontWeight: totalRequired > totalCapacity ? 700 : 400 }}>
                    Capacity: {totalCapacity}
                  </span>
                </div>
              </Panel>

              {/* Teacher load */}
              {Object.keys(teacherLoad).length > 0 && (
                <Panel title="Teacher Load" icon={<Users size={16} />} theme={theme} collapsed={collapsedPanels.teachers} onToggle={() => togglePanel("teachers")}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                    {Object.entries(teacherLoad).sort((a, b) => b[1] - a[1]).map(([teacher, count]) => (
                      <div key={teacher} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ flex: 1, fontSize: 12.5, color: theme.textSoft }}>{teacher}</span>
                        <div style={{ width: 80, height: 6, borderRadius: 3, background: darkMode ? "#2a2d50" : "#EDE8DB", overflow: "hidden" }}>
                          <div style={{ width: `${Math.min(100, (count / (activeDays.length * 2)) * 100)}%`, height: "100%", borderRadius: 3, background: count > activeDays.length * 1.5 ? theme.danger : `linear-gradient(90deg, ${theme.accent}, #F0B85A)` }} />
                        </div>
                        <span style={{ fontSize: 11, fontWeight: 700, color: count > activeDays.length * 1.5 ? theme.danger : theme.success, minWidth: 45, textAlign: "right" }}>{count} per</span>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => { setSubstituteMode(!substituteMode); setAbsentTeacher(""); }} style={{
                    marginTop: 10, width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    padding: "8px", borderRadius: 8, border: `1px solid ${substituteMode ? theme.accent : theme.border}`,
                    background: substituteMode ? `${theme.accent}15` : "transparent",
                    color: substituteMode ? theme.accent : theme.textSoft, fontSize: 12, fontWeight: 600, cursor: "pointer",
                  }}>
                    <UserX size={14} /> {substituteMode ? "Exit substitute mode" : "Substitution planner"}
                  </button>
                  {substituteMode && (
                    <div className="fade-in" style={{ marginTop: 8 }}>
                      <select
                        value={absentTeacher}
                        onChange={(e) => setAbsentTeacher(e.target.value)}
                        style={{ ...selectSt, width: "100%" }}
                      >
                        <option value="">Select absent teacher…</option>
                        {[...new Set(subjects.map((s) => s.teacher).filter(Boolean))].sort().map((t) => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                      {affectedCells.length > 0 && (
                        <div style={{ marginTop: 8, fontSize: 11.5, color: theme.accent, fontWeight: 600 }}>
                          {affectedCells.length} period(s) affected — highlighted in yellow on the grid
                        </div>
                      )}
                    </div>
                  )}
                </Panel>
              )}

              {/* Daily Hours Summary */}
              <Panel title="Daily Hours" icon={<TrendingUp size={16} />} theme={theme} collapsed={collapsedPanels.hours} onToggle={() => togglePanel("hours")}>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {activeDays.map((day) => {
                    const mins = dayHours[day] || 0;
                    const hrs = (mins / 60).toFixed(1);
                    return (
                      <div key={day} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ width: 30, fontSize: 12, fontWeight: 600, color: theme.textSoft }}>{day}</span>
                        <div style={{ flex: 1, height: 8, borderRadius: 4, background: darkMode ? "#2a2d50" : "#EDE8DB", overflow: "hidden" }}>
                          <div style={{ width: `${Math.min(100, (mins / (periodSlots.length * 45)) * 100)}%`, height: "100%", borderRadius: 4, background: "linear-gradient(90deg, #3F9B76, #68D391)", transition: "width 0.3s" }} />
                        </div>
                        <span style={{ fontSize: 11.5, fontWeight: 700, color: theme.text, minWidth: 40, textAlign: "right" }}>{hrs}h</span>
                      </div>
                    );
                  })}
                </div>
              </Panel>
            </div>

            {/* RIGHT PANEL: TIMETABLE & OPTIMIZER */}
            <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 16 }}>
              {/* Optimizer Console */}
              <div className="no-print" style={{
                background: theme.bgOptimizer, borderRadius: 16, padding: "20px 24px", color: "#fff",
                boxShadow: "0 8px 32px rgba(0,0,0,0.15)",
              }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 14 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: "linear-gradient(135deg, #E8A33D, #F0B85A)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      animation: gaState.running ? "pulseGlow 1.5s infinite" : "none",
                    }}>
                      <Zap size={18} color="#22265E" />
                    </div>
                    <div>
                      <div className="disp" style={{ fontWeight: 700, fontSize: 16 }}>Genetic Algorithm Optimizer</div>
                      <div style={{ fontSize: 12, color: "rgba(183,187,224,0.7)" }}>Auto-arranges into a clash-minimized, 100% filled timetable</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    {!gaState.running ? (
                      <button onClick={runOptimizer} className="btn-primary">
                        <Play size={15} fill="#22265E" /> Auto-generate
                      </button>
                    ) : (
                      <button onClick={stopOptimizer} className="btn-primary" style={{ background: "rgba(255,255,255,0.15)", color: "#fff" }}>
                        <X size={15} /> Stop
                      </button>
                    )}
                    <button onClick={clearAll} className="btn-ghost-dark">
                      <RotateCcw size={14} /> Clear
                    </button>
                  </div>
                </div>

                {(gaState.running || gaState.history.length > 0) && (
                  <div className="fade-in" style={{ marginTop: 18, paddingTop: 18, borderTop: "1px solid rgba(255,255,255,0.1)" }}>
                    <div style={{ display: "flex", gap: 28, marginBottom: 10, flexWrap: "wrap" }}>
                      <Stat label="Generation" value={`${gaState.gen} / ${gaState.totalGens}`} />
                      <Stat label="Fitness" value={gaState.fitness.toFixed(4)} />
                      <Stat label="Conflicts" value={gaState.history.length ? gaState.history[gaState.history.length - 1].conflicts : "—"} />
                      <Stat label="Status" value={gaState.running ? "Evolving…" : "✓ 100% Converged"} highlight={!gaState.running} />
                    </div>
                    <div className="progress-bar" style={{ marginBottom: 12, height: 5, background: "rgba(255,255,255,0.1)" }}>
                      <div className="progress-fill" style={{ width: `${(gaState.gen / gaState.totalGens) * 100}%` }} />
                    </div>
                    <FitnessChart history={gaState.history} />
                  </div>
                )}
              </div>

              {/* Heatmap Legend / Status Bar */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
                {heatmapMode ? (
                  <div style={{ display: "flex", gap: 12, alignItems: "center", fontSize: 11.5, color: theme.textSoft }}>
                    <span style={{ fontWeight: 700, color: theme.text }}>🔥 Heatmap Mode:</span>
                    <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      <span style={{ width: 10, height: 10, borderRadius: 3, background: HEATMAP_COLORS[3].border }} /> High Theory
                    </span>
                    <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      <span style={{ width: 10, height: 10, borderRadius: 3, background: HEATMAP_COLORS[2].border }} /> Medium / Lab
                    </span>
                    <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      <span style={{ width: 10, height: 10, borderRadius: 3, background: HEATMAP_COLORS[1].border }} /> Light / Activity
                    </span>
                  </div>
                ) : (
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                    {subjects.map((s) => {
                      const c = SUBJECT_COLORS[s.color % SUBJECT_COLORS.length];
                      return (
                        <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11.5, color: theme.textSoft }}>
                          <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.dot, boxShadow: `0 0 4px ${c.glow}` }} />
                          {s.name}
                        </div>
                      );
                    })}
                  </div>
                )}

                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div className="progress-bar" style={{ width: 100 }}>
                    <div className="progress-fill" style={{ width: `${fillPct}%`, background: fillPct === 100 ? "linear-gradient(90deg, #38A169, #68D391)" : undefined }} />
                  </div>
                  <span style={{ fontSize: 12, color: theme.textSoft, fontWeight: 600, whiteSpace: "nowrap" }}>
                    {filled}/{totalCapacity} ({fillPct}%)
                  </span>
                </div>
              </div>

              {/* Timetable Grid */}
              <div className="glass-card" style={{ overflow: "hidden", background: theme.bgCard, border: `1px solid ${theme.border}` }}>
                <div style={{ overflowX: "auto" }}>
                  <div style={{ display: "grid", gridTemplateColumns: `140px repeat(${activeDays.length}, 1fr)`, minWidth: 140 + activeDays.length * 155 }}>
                    <div style={{
                      padding: "14px 16px", background: darkMode ? "rgba(30,34,96,0.5)" : "#F4F0E5",
                      fontSize: 11.5, fontWeight: 700, color: theme.textSoft, borderBottom: `1px solid ${theme.border}`,
                      borderRight: `1px solid ${theme.border}`, textTransform: "uppercase", letterSpacing: 0.5,
                    }}>
                      Time
                    </div>
                    {activeDays.map((d, di) => (
                      <div key={d} className="disp" style={{
                        padding: "14px 16px",
                        background: darkMode ? `rgba(30,34,96,${0.3 + di * 0.04})` : `rgba(244,240,229,${1 - di * 0.06})`,
                        fontSize: 14, fontWeight: 700, color: theme.text, borderBottom: `1px solid ${theme.border}`,
                        textAlign: "center", letterSpacing: -0.3,
                      }}>
                        {DAY_FULL[d]}
                      </div>
                    ))}

                    {timedTemplate.map((slot) => (
                      <React.Fragment key={slot.id}>
                        <div style={{
                          padding: "10px 14px", fontSize: 11, color: theme.textMuted, fontWeight: 600,
                          borderRight: `1px solid ${theme.borderSoft}`, borderBottom: `1px solid ${theme.borderSoft}`,
                          display: "flex", flexDirection: "column", justifyContent: "center", background: theme.bgCard,
                        }}>
                          <span style={{ fontSize: 11.5, color: theme.textSoft, fontWeight: 700 }}>{slot.label}</span>
                          <span style={{ fontSize: 10.5 }}>{minutesToLabel(slot.start)} – {minutesToLabel(slot.end)}</span>
                        </div>
                        {slot.type === "break" ? (
                          <div style={{
                            gridColumn: `span ${activeDays.length}`,
                            padding: "10px 14px",
                            background: slot.isLunch
                              ? (darkMode ? "rgba(201,162,39,0.1)" : "#FBF3D9")
                              : (darkMode ? "rgba(255,255,255,0.03)" : "#F7F4EC"),
                            color: slot.isLunch ? "#C9A227" : theme.textMuted,
                            fontSize: 12, fontWeight: 700, textAlign: "center",
                            borderBottom: `1px solid ${theme.borderSoft}`, letterSpacing: 0.5,
                            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                          }}>
                            <Coffee size={13} />
                            {slot.label.toUpperCase()} · {slot.duration} MIN
                          </div>
                        ) : (
                          activeDays.map((day) => {
                            const key = cellKey(day, slot.id);
                            const subjId = schedule[key];
                            const subj = subjects.find((s) => s.id === subjId);
                            const c = subj ? SUBJECT_COLORS[subj.color % SUBJECT_COLORS.length] : null;
                            const isEditing = editingCell && editingCell.day === day && editingCell.slotId === slot.id;
                            const isAffected = affectedCells.some((ac) => ac.day === day && ac.slotId === slot.id);
                            const tb = subj ? (TYPE_BADGES[subj.type] || TYPE_BADGES.Theory) : null;

                            // Heatmap styling override
                            const loadLevel = tb ? tb.load : 2;
                            const hmStyle = heatmapMode && subj ? HEATMAP_COLORS[loadLevel] : null;

                            return (
                              <div key={key} style={{
                                position: "relative",
                                borderRight: `1px solid ${theme.borderSoft}`,
                                borderBottom: `1px solid ${theme.borderSoft}`,
                                minHeight: 68,
                                background: isAffected ? "rgba(232,163,61,0.15)" : (hmStyle ? hmStyle.bg : "transparent"),
                                transition: "background 0.2s",
                              }}>
                                {subj ? (
                                  <div
                                    className="cell-btn"
                                    onClick={() => setEditingCell({ day, slotId: slot.id })}
                                    style={{
                                      height: "100%", padding: "9px 11px", cursor: "pointer",
                                      background: hmStyle ? hmStyle.bg : (darkMode ? `${c.border}18` : c.bg),
                                      borderLeft: `3.5px solid ${hmStyle ? hmStyle.border : c.border}`,
                                      position: "relative",
                                    }}
                                  >
                                    <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                                      <div style={{ fontSize: 12.5, fontWeight: 700, color: hmStyle ? hmStyle.text : (darkMode ? c.border : c.text) }}>{subj.name}</div>
                                    </div>
                                    <div style={{ fontSize: 10.5, color: hmStyle ? `${hmStyle.text}B0` : (darkMode ? `${c.border}B0` : `${c.text}B0`), marginTop: 2 }}>
                                      {subj.teacher ? subj.teacher : <span style={{ opacity: 0.5 }}>Type teacher name</span>}
                                      {subj.code ? ` · ${subj.code}` : ""}
                                    </div>
                                    {tb && (
                                      <span style={{
                                        position: "absolute", top: 4, right: 5,
                                        fontSize: 8.5, padding: "1px 4px", borderRadius: 4,
                                        background: darkMode ? `${c.border}20` : tb.bg,
                                        color: darkMode ? c.border : tb.color, fontWeight: 700,
                                      }}>
                                        {subj.type}
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => setEditingCell({ day, slotId: slot.id })}
                                    className="cell-btn no-print"
                                    style={{
                                      width: "100%", height: "100%", minHeight: 68, background: "transparent",
                                      border: "none", color: theme.textMuted, fontSize: 12, cursor: "pointer",
                                      display: "flex", alignItems: "center", justifyContent: "center", gap: 4,
                                      opacity: 0.5, transition: "opacity 0.2s",
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.opacity = "1"}
                                    onMouseLeave={(e) => e.currentTarget.style.opacity = "0.5"}
                                  >
                                    <Plus size={14} /> Add
                                  </button>
                                )}

                                {isEditing && (
                                  <CellPicker
                                    subjects={subjects}
                                    onSelect={(id) => setCellSubject(day, slot.id, id)}
                                    onClose={() => setEditingCell(null)}
                                    theme={theme}
                                    darkMode={darkMode}
                                  />
                                )}
                              </div>
                            );
                          })
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              <div className="no-print" style={{ fontSize: 12, color: theme.textMuted, textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                <Info size={13} /> Click any cell to assign manually, or use the optimizer. Setting an Elective slot syncs across all sections!
              </div>
            </div>
          </div>
        </div>

        {/* PAGE 2 FOR PRINTING */}
        <div className="print-page-2" style={{ maxWidth: 1480, margin: "0 auto", padding: "0 28px 28px 28px" }}>
          <div className="glass-card" style={{ padding: 24, background: theme.bgCard, border: `1px solid ${theme.border}` }}>
            <div className="disp" style={{ fontSize: 18, fontWeight: 700, color: theme.text, marginBottom: 6, display: "flex", alignItems: "center", gap: 8 }}>
              <Target size={19} color={theme.accent} /> Course & Program Outcomes (Page 2)
            </div>
            <div style={{ fontSize: 12, color: theme.textMuted, marginBottom: 20 }}>
              Track the learning outcomes and correlation matrix supported by this timetable.
            </div>

            <OutcomeBlock
              title="Course Outcomes (CO)" icon={<ListChecks size={15} />}
              items={outcomes.courseOutcomes || []}
              onAdd={() => addOutcome("CO")}
              onUpdate={(id, patch) => updateOutcome("CO", id, patch)}
              onRemove={(id) => removeOutcome("CO", id)}
              theme={theme}
            />

            <div style={{ height: 20 }} />

            <OutcomeBlock
              title="Program Outcomes (PO)" icon={<FileText size={15} />}
              items={outcomes.programOutcomes || []}
              onAdd={() => addOutcome("PO")}
              onUpdate={(id, patch) => updateOutcome("PO", id, patch)}
              onRemove={(id) => removeOutcome("PO", id)}
              theme={theme}
            />

            {(outcomes.courseOutcomes?.length > 0 && outcomes.programOutcomes?.length > 0) && (
              <div style={{ marginTop: 24 }}>
                <div style={{ fontSize: 13.5, fontWeight: 700, color: theme.textSoft, marginBottom: 10 }}>CO–PO Mapping (Correlation Matrix)</div>
                <CoPoMatrix
                  courseOutcomes={outcomes.courseOutcomes}
                  programOutcomes={outcomes.programOutcomes}
                  values={copoMatrix}
                  onChange={setCopoMatrix}
                  theme={theme}
                  darkMode={darkMode}
                />
                <div style={{ fontSize: 11, color: theme.textMuted, marginTop: 8 }}>1 = slightly, 2 = moderately, 3 = strongly correlated. Click a cell to cycle values.</div>
              </div>
            )}

            <div style={{ marginTop: 24 }}>
              <div style={{ fontSize: 13.5, fontWeight: 700, color: theme.textSoft, marginBottom: 8 }}>Additional Remarks & Approvals</div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Remarks about schedule, substitution policy, effective date, teacher signatures…"
                style={{
                  width: "100%", minHeight: 90, padding: 12, borderRadius: 10,
                  border: `1px solid ${theme.border}`, fontSize: 13, resize: "vertical",
                  background: theme.bgAlt, color: theme.text,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {showFullscreen && (
        <FullscreenView
          schedule={schedule} subjects={subjects} activeDays={activeDays}
          timedTemplate={timedTemplate} cellKey={cellKey} theme={theme} darkMode={darkMode}
          instituteInfo={instituteInfo}
          onClose={() => setShowFullscreen(false)}
        />
      )}
    </div>
  );
}

/* ================================================================
   MULTI-SECTION MASTER OVERVIEW MODAL
   ================================================================ */

function MasterOverviewModal({ sections, theme, darkMode, onClose }) {
  const activeDays = sections[0]?.activeDays || ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const template = sections[0]?.template || defaultSlotTemplate();
  const periodSlots = template.filter((s) => s.type === "period");

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 1000,
      background: "rgba(0,0,0,0.85)", backdropFilter: "blur(12px)",
      display: "flex", flexDirection: "column", animation: "fadeIn 0.3s ease",
    }}>
      <div style={{
        padding: "18px 28px", display: "flex", alignItems: "center", justifyContent: "space-between",
        borderBottom: `1px solid ${theme.border}`, background: theme.bgHeader, color: "#fff",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Grid size={20} color={theme.accent} />
          <div>
            <div className="disp" style={{ fontSize: 18, fontWeight: 700 }}>Multi-Section Master Overview</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)" }}>Side-by-side comparison across all {sections.length} active class section(s)</div>
          </div>
        </div>
        <button onClick={onClose} className="btn-ghost-dark">
          <X size={16} /> Close
        </button>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: 24, background: theme.bg }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 24, maxWidth: 1600, margin: "0 auto" }}>
          {activeDays.map((day) => (
            <div key={day} className="glass-card" style={{ padding: 18, background: theme.bgCard, border: `1px solid ${theme.border}` }}>
              <div className="disp" style={{ fontSize: 16, fontWeight: 700, color: theme.text, marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
                <Calendar size={16} color={theme.accent} /> {DAY_FULL[day]}
              </div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                  <thead>
                    <tr>
                      <th style={{ padding: "10px", textAlign: "left", color: theme.textSoft, borderBottom: `1px solid ${theme.border}`, width: 110 }}>Period</th>
                      {sections.map((sec) => (
                        <th key={sec.id} style={{ padding: "10px", textAlign: "center", color: theme.accent, fontWeight: 700, borderBottom: `1px solid ${theme.border}`, background: `${theme.accent}10` }}>
                          {sec.sectionName}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {periodSlots.map((slot) => (
                      <tr key={slot.id}>
                        <td style={{ padding: "10px", fontWeight: 700, color: theme.textMuted, borderBottom: `1px solid ${theme.borderSoft}` }}>
                          {slot.label}
                        </td>
                        {sections.map((sec) => {
                          const key = `${day}-${slot.id}`;
                          const subjId = sec.schedule[key];
                          const subj = sec.subjects.find((s) => s.id === subjId);
                          const c = subj ? SUBJECT_COLORS[subj.color % SUBJECT_COLORS.length] : null;
                          return (
                            <td key={sec.id} style={{
                              padding: "8px 10px", textAlign: "center", border: `1px solid ${theme.borderSoft}`,
                              background: c ? (darkMode ? `${c.border}15` : c.bg) : "transparent",
                            }}>
                              {subj ? (
                                <div>
                                  <div style={{ fontWeight: 700, color: darkMode ? c.border : c.text }}>{subj.name}</div>
                                  <div style={{ fontSize: 10.5, color: theme.textMuted }}>{subj.teacher || "TBA"}</div>
                                </div>
                              ) : (
                                <span style={{ color: theme.textMuted, opacity: 0.4 }}>—</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   STATISTICS DASHBOARD
   ================================================================ */

function StatsDashboard({ subjects, schedule, activeDays, periodSlots, cellKey, dayHours, placedCounts, teacherLoad, theme, darkMode }) {
  const totalSlots = activeDays.length * periodSlots.length;
  const filledSlots = Object.keys(schedule).length;
  const emptySlots = totalSlots - filledSlots;

  const cardSt = {
    flex: "1 1 160px", padding: "16px 18px", borderRadius: 14,
    background: theme.bgCard, border: `1px solid ${theme.border}`,
    backdropFilter: "blur(12px)", boxShadow: theme.cardShadow,
  };

  return (
    <div className="fade-in">
      <div className="disp" style={{ fontSize: 17, fontWeight: 700, color: theme.text, marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
        <BarChart3 size={18} color={theme.accent} /> Statistics Dashboard
      </div>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
        <div style={cardSt}>
          <div style={{ fontSize: 11, color: theme.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>Fill Rate</div>
          <div className="disp" style={{ fontSize: 28, fontWeight: 700, color: filledSlots >= totalSlots ? theme.success : theme.accent }}>
            {totalSlots > 0 ? Math.round((filledSlots / totalSlots) * 100) : 0}%
          </div>
          <div style={{ fontSize: 11, color: theme.textMuted }}>{filledSlots}/{totalSlots} slots placed</div>
        </div>
        <div style={cardSt}>
          <div style={{ fontSize: 11, color: theme.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>Empty Slots</div>
          <div className="disp" style={{ fontSize: 28, fontWeight: 700, color: emptySlots > 0 ? theme.danger : theme.success }}>{emptySlots}</div>
          <div style={{ fontSize: 11, color: theme.textMuted }}>of {totalSlots} total</div>
        </div>
        <div style={cardSt}>
          <div style={{ fontSize: 11, color: theme.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>Subjects</div>
          <div className="disp" style={{ fontSize: 28, fontWeight: 700, color: theme.text }}>{subjects.length}</div>
          <div style={{ fontSize: 11, color: theme.textMuted }}>{Object.keys(teacherLoad).length} active teachers</div>
        </div>
        <div style={cardSt}>
          <div style={{ fontSize: 11, color: theme.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>Avg. Daily</div>
          <div className="disp" style={{ fontSize: 28, fontWeight: 700, color: theme.text }}>
            {activeDays.length > 0 ? (Object.values(dayHours).reduce((a, b) => a + b, 0) / activeDays.length / 60).toFixed(1) : 0}h
          </div>
          <div style={{ fontSize: 11, color: theme.textMuted }}>{activeDays.length} days/week</div>
        </div>
      </div>

      <div style={{ ...cardSt, flex: "none", marginBottom: 0 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, color: theme.textSoft, marginBottom: 12 }}>Subject Placement</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {subjects.map((s) => {
            const c = SUBJECT_COLORS[s.color % SUBJECT_COLORS.length];
            const placed = placedCounts[s.id] || 0;
            const pct = s.periodsPerWeek > 0 ? Math.min(100, (placed / s.periodsPerWeek) * 100) : 0;
            return (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ width: 110, fontSize: 11.5, fontWeight: 600, color: theme.textSoft, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</span>
                <div style={{ flex: 1, height: 10, borderRadius: 5, background: darkMode ? "#2a2d50" : "#EDE8DB", overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", borderRadius: 5, background: `linear-gradient(90deg, ${c.border}, ${c.dot})`, transition: "width 0.4s ease" }} />
                </div>
                <span style={{ fontSize: 11, fontWeight: 700, color: placed >= s.periodsPerWeek ? theme.success : theme.textMuted, minWidth: 40, textAlign: "right" }}>
                  {placed}/{s.periodsPerWeek}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   FULLSCREEN VIEW
   ================================================================ */

function FullscreenView({ schedule, subjects, activeDays, timedTemplate, cellKey, theme, darkMode, instituteInfo, onClose }) {
  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 1000,
      background: darkMode ? "rgba(0,0,0,0.9)" : "rgba(0,0,0,0.85)",
      backdropFilter: "blur(8px)",
      display: "flex", flexDirection: "column",
      animation: "fadeIn 0.3s ease",
    }}>
      <div style={{
        padding: "16px 28px", display: "flex", alignItems: "center", justifyContent: "space-between",
        borderBottom: "1px solid rgba(255,255,255,0.1)",
      }}>
        <div>
          <div className="disp" style={{ fontSize: 20, fontWeight: 700, color: "#fff" }}>{instituteInfo.className}</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>{instituteInfo.institute} · {instituteInfo.academicYear}</div>
        </div>
        <button onClick={onClose} style={{
          background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)",
          borderRadius: 10, padding: "10px 16px", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer",
          display: "flex", alignItems: "center", gap: 6,
        }}>
          <Minimize2 size={15} /> Exit fullscreen
        </button>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: 24 }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: `140px repeat(${activeDays.length}, 1fr)`,
          gap: 0, background: "rgba(255,255,255,0.05)", borderRadius: 16, overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.1)",
        }}>
          <div style={{ padding: 16, fontWeight: 700, color: "rgba(255,255,255,0.5)", fontSize: 12, textTransform: "uppercase", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
            Time
          </div>
          {activeDays.map((d) => (
            <div key={d} className="disp" style={{
              padding: 16, fontWeight: 700, color: "#fff", fontSize: 15, textAlign: "center",
              borderBottom: "1px solid rgba(255,255,255,0.08)",
            }}>
              {DAY_FULL[d]}
            </div>
          ))}
          {timedTemplate.map((slot) => (
            <React.Fragment key={slot.id}>
              <div style={{
                padding: "12px 14px", fontSize: 11, color: "rgba(255,255,255,0.4)", fontWeight: 600,
                borderBottom: "1px solid rgba(255,255,255,0.05)", display: "flex", flexDirection: "column", justifyContent: "center",
              }}>
                <span style={{ fontSize: 11.5, color: "rgba(255,255,255,0.6)", fontWeight: 700 }}>{slot.label}</span>
                {minutesToLabel(slot.start)} – {minutesToLabel(slot.end)}
              </div>
              {slot.type === "break" ? (
                <div style={{
                  gridColumn: `span ${activeDays.length}`, padding: 12, textAlign: "center",
                  fontSize: 12, fontWeight: 700, letterSpacing: 0.5,
                  color: slot.isLunch ? "#C9A227" : "rgba(255,255,255,0.3)",
                  background: slot.isLunch ? "rgba(201,162,39,0.08)" : "rgba(255,255,255,0.02)",
                  borderBottom: "1px solid rgba(255,255,255,0.05)",
                }}>
                  ☕ {slot.label.toUpperCase()} · {slot.duration} MIN
                </div>
              ) : (
                activeDays.map((day) => {
                  const key = cellKey(day, slot.id);
                  const subjId = schedule[key];
                  const subj = subjects.find((s) => s.id === subjId);
                  const c = subj ? SUBJECT_COLORS[subj.color % SUBJECT_COLORS.length] : null;
                  return (
                    <div key={key} style={{
                      borderBottom: "1px solid rgba(255,255,255,0.05)",
                      borderRight: "1px solid rgba(255,255,255,0.03)",
                      minHeight: 72,
                    }}>
                      {subj ? (
                        <div style={{
                          height: "100%", padding: "10px 12px",
                          background: `${c.border}15`, borderLeft: `4px solid ${c.border}`,
                        }}>
                          <div style={{ fontSize: 14, fontWeight: 700, color: c.border }}>{subj.name}</div>
                          <div style={{ fontSize: 11, color: `${c.border}90`, marginTop: 2 }}>{subj.teacher || "TBA"} · {subj.code}</div>
                        </div>
                      ) : (
                        <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.1)", fontSize: 12 }}>—</div>
                      )}
                    </div>
                  );
                })
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   CO-PO MATRIX
   ================================================================ */

function CoPoMatrix({ courseOutcomes, programOutcomes, values, onChange, theme, darkMode }) {
  function cycle(coId, poId) {
    const key = `${coId}_${poId}`;
    onChange((prev) => {
      const cur = prev[key] || 0;
      return { ...prev, [key]: (cur + 1) % 4 };
    });
  }

  const cellColors = [
    darkMode ? "rgba(255,255,255,0.03)" : "#F7F4EC",
    darkMode ? "rgba(201,162,39,0.15)" : "#FBF3D9",
    darkMode ? "rgba(219,138,76,0.15)" : "#FDEDE3",
    darkMode ? "rgba(63,155,118,0.15)" : "#E3F1EC",
  ];

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr>
            <th style={{ padding: "8px 12px", fontWeight: 700, color: theme.textSoft, borderBottom: `1px solid ${theme.border}` }}></th>
            {programOutcomes.map((po) => (
              <th key={po.id} style={{ padding: "8px 12px", fontWeight: 700, color: theme.textSoft, borderBottom: `1px solid ${theme.border}`, textAlign: "center" }} title={po.text}>
                {po.code}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {courseOutcomes.map((co) => (
            <tr key={co.id}>
              <td style={{ padding: "8px 12px", fontWeight: 700, color: theme.textSoft, textAlign: "left" }}>{co.code}</td>
              {programOutcomes.map((po) => {
                const key = `${co.id}_${po.id}`;
                const val = values[key] || 0;
                return (
                  <td
                    key={po.id}
                    onClick={() => cycle(co.id, po.id)}
                    style={{
                      padding: "8px 12px", textAlign: "center",
                      border: `1px solid ${theme.borderSoft}`, cursor: "pointer",
                      minWidth: 38, fontWeight: 700, borderRadius: 0,
                      background: cellColors[val],
                      color: val === 0 ? theme.textMuted : theme.text,
                      transition: "all 0.15s ease",
                    }}
                  >
                    {val === 0 ? "—" : val}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ================================================================
   OUTCOME BLOCK
   ================================================================ */

function OutcomeBlock({ title, icon, items, onAdd, onUpdate, onRemove, theme }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 13.5, fontWeight: 700, color: theme.text, marginBottom: 10 }}>
        {icon} {title}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {items.map((item) => (
          <div key={item.id} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
            <input
              value={item.code}
              onChange={(e) => onUpdate(item.id, { code: e.target.value })}
              style={{ width: 56, padding: "8px 8px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: 12, fontWeight: 700, flexShrink: 0, color: theme.text, background: theme.bgAlt }}
            />
            <textarea
              value={item.text}
              onChange={(e) => onUpdate(item.id, { text: e.target.value })}
              placeholder="Describe this outcome…"
              rows={1}
              style={{ flex: 1, padding: "8px 10px", borderRadius: 8, border: `1px solid ${theme.border}`, fontSize: 12.5, resize: "vertical", background: theme.bgAlt, color: theme.text }}
            />
            <button onClick={() => onRemove(item.id)} style={{ background: "none", border: "none", cursor: "pointer", color: theme.danger, padding: 4, flexShrink: 0, opacity: 0.5 }}>
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>
      <MiniAddBtn onClick={onAdd} theme={theme} style={{ marginTop: 8 }}>
        <Plus size={12} /> Add {title.includes("Course") ? "CO" : "PO"}
      </MiniAddBtn>
    </div>
  );
}

/* ================================================================
   SMALL SUBCOMPONENTS
   ================================================================ */

function EditableField({ label, value, onChange, big, theme }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: theme.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>{label}</div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="disp"
        style={{
          fontSize: big ? 17 : 13.5, fontWeight: big ? 700 : 600, color: theme.text,
          border: "none", background: "transparent", width: "100%", padding: 0,
          borderBottom: `1px dashed transparent`, transition: "border-color 0.2s",
        }}
        onFocus={(e) => (e.target.style.borderBottom = `1px dashed ${theme.accent}`)}
        onBlur={(e) => (e.target.style.borderBottom = "1px dashed transparent")}
      />
    </div>
  );
}

function Panel({ title, icon, children, theme, collapsed, onToggle }) {
  return (
    <div className="glass-card panel-hover" style={{
      background: theme.bgPanel, border: `1px solid ${theme.glassBorder}`,
      backdropFilter: "blur(16px)", padding: collapsed ? "12px 16px" : 16,
      transition: "all 0.3s ease",
    }}>
      <div
        onClick={onToggle}
        className="disp"
        style={{
          display: "flex", alignItems: "center", gap: 8, fontSize: 14, fontWeight: 700,
          marginBottom: collapsed ? 0 : 12, color: theme.text, cursor: "pointer",
          userSelect: "none",
        }}
      >
        {icon} <span style={{ flex: 1 }}>{title}</span>
        {onToggle && (collapsed ? <ChevronDown size={16} color={theme.textMuted} /> : <ChevronUp size={16} color={theme.textMuted} />)}
      </div>
      {!collapsed && <div className="fade-in">{children}</div>}
    </div>
  );
}

function SlotRow({ slot, onUpdate, onRemove, theme }) {
  const isBreak = slot.type === "break";
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6, padding: "7px 9px", borderRadius: 9,
      background: isBreak ? (theme === THEMES.dark ? "rgba(201,162,39,0.08)" : "#FBF3D9") : theme.bgAlt,
      border: `1px solid ${isBreak ? (theme === THEMES.dark ? "rgba(201,162,39,0.2)" : "#F0E4BC") : theme.border}`,
      transition: "all 0.2s ease",
    }}>
      <GripVertical size={12} color={theme.textMuted} />
      <input
        value={slot.label}
        onChange={(e) => onUpdate({ label: e.target.value })}
        style={{
          flex: 1, minWidth: 0, fontSize: 12, fontWeight: 600, border: "none",
          background: "transparent", padding: "3px 2px",
          color: isBreak ? "#C9A227" : theme.text,
        }}
      />
      <input
        type="number" min={5} max={180} value={slot.duration}
        onChange={(e) => onUpdate({ duration: Math.max(5, parseInt(e.target.value) || 5) })}
        style={{
          width: 44, fontSize: 11.5, textAlign: "center",
          border: `1px solid ${theme.border}`, borderRadius: 6, padding: "3px 2px",
          background: theme.bgAlt, color: theme.text,
        }}
      />
      <span style={{ fontSize: 10, color: theme.textMuted }}>min</span>
      <button onClick={onRemove} style={{ background: "none", border: "none", cursor: "pointer", color: theme.danger, padding: 2, flexShrink: 0, opacity: 0.5 }}>
        <Trash2 size={12} />
      </button>
    </div>
  );
}

function MiniAddBtn({ onClick, children, theme, full, style: extraStyle }) {
  return (
    <button onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 4,
      background: theme.bgAlt, border: `1px solid ${theme.border}`,
      borderRadius: 7, padding: "5px 9px", fontSize: 11, fontWeight: 600,
      color: theme.textSoft, cursor: "pointer", transition: "all 0.2s",
      ...(full ? { width: "100%", justifyContent: "center", padding: "9px" } : {}),
      ...extraStyle,
    }}>
      {children}
    </button>
  );
}

function Stat({ label, value, highlight }) {
  return (
    <div>
      <div style={{ fontSize: 10.5, color: "rgba(132,137,196,0.8)", textTransform: "uppercase", letterSpacing: 0.6, fontWeight: 600 }}>{label}</div>
      <div className="disp" style={{ fontSize: 18, fontWeight: 700, color: highlight ? "#7FD9A8" : "#fff", letterSpacing: -0.3 }}>{value}</div>
    </div>
  );
}

function FitnessChart({ history }) {
  const w = 640;
  const h = 70;
  if (history.length < 2) return <div style={{ height: h }} />;
  const points = history.map((p, i) => {
    const x = (i / (history.length - 1)) * w;
    const y = h - p.bestFitness * h;
    return `${x},${y}`;
  });
  const gradId = `fit-grad-${history.length}`;
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: "block" }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#E8A33D" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#E8A33D" stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${h} ${points.join(" ")} ${w},${h}`} fill={`url(#${gradId})`} />
      <polyline points={points.join(" ")} fill="none" stroke="#E8A33D" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CellPicker({ subjects, onSelect, onClose, theme, darkMode }) {
  const [search, setSearch] = useState("");
  const filtered = subjects.filter((s) =>
    !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.teacher.toLowerCase().includes(search.toLowerCase()) || s.code.toLowerCase().includes(search.toLowerCase())
  );
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 10 }} />
      <div
        className="fade-in"
        style={{
          position: "absolute", top: "100%", left: 0, zIndex: 20,
          background: theme.bgAlt, border: `1px solid ${theme.border}`,
          borderRadius: 12, boxShadow: "0 12px 40px rgba(0,0,0,0.15)",
          padding: 8, minWidth: 220, maxHeight: 320, overflowY: "auto",
          backdropFilter: "blur(16px)",
        }}
      >
        <div style={{ padding: "4px 6px", marginBottom: 4 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 6, padding: "6px 8px",
            borderRadius: 8, border: `1px solid ${theme.border}`, background: theme.bgCard,
          }}>
            <Search size={13} color={theme.textMuted} />
            <input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search…"
              style={{ flex: 1, border: "none", background: "transparent", fontSize: 12, outline: "none", color: theme.text }}
            />
          </div>
        </div>
        <button
          onClick={() => onSelect(null)}
          style={{
            width: "100%", textAlign: "left", padding: "8px 10px", fontSize: 12.5,
            border: "none", background: "none", cursor: "pointer",
            color: theme.textMuted, borderRadius: 8, transition: "background 0.15s",
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = theme.cellHover}
          onMouseLeave={(e) => e.currentTarget.style.background = "none"}
        >
          ✕ Clear slot
        </button>
        {filtered.map((s) => {
          const c = SUBJECT_COLORS[s.color % SUBJECT_COLORS.length];
          const tb = TYPE_BADGES[s.type] || TYPE_BADGES.Theory;
          return (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              style={{
                width: "100%", display: "flex", alignItems: "center", gap: 8,
                textAlign: "left", padding: "8px 10px", fontSize: 12.5,
                border: "none", background: "none", cursor: "pointer",
                borderRadius: 8, fontWeight: 600, color: theme.text,
                transition: "background 0.15s",
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = theme.cellHover}
              onMouseLeave={(e) => e.currentTarget.style.background = "none"}
            >
              <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.dot, flexShrink: 0 }} />
              <span style={{ flex: 1 }}>{s.name}</span>
              <span style={{ fontSize: 9.5, padding: "1px 5px", borderRadius: 4, background: tb.bg, color: tb.color, fontWeight: 700 }}>
                {tb.icon}
              </span>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <div style={{ padding: "12px 10px", fontSize: 12, color: theme.textMuted, textAlign: "center" }}>No matches</div>
        )}
      </div>
    </>
  );
}
